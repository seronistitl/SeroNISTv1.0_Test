

observeEvent(input$fileUploadInput, {
  # Get the datapath from the file upload
  datapath = paste0("Data/", input$fileUploadInput[1])
  # Write to reactive variable
  rv$fileUploadPath = datapath
  # Check file extension
  
  # Do the upload
  
  # Get available sheets in the upload if excel
  currSheets = excel_sheets(rv$fileUploadPath)
  
  output$selectSheet <- renderUI({
    selectInput("selectSheet",
                "Select Excel sheet to upload",
                choices = currSheets,
                selected = currSheets[1])
  })
  
})



observeEvent(input$selectSheet, {
  rv$excelSheetSelected = input$selectSheet
  
})

observeEvent(input$addUniqueColAnyway, {
  rv$addUniqueColAnyway = input$addUniqueColAnyway
  
  if (rv$addUniqueColAnyway == FALSE){
    # When a sheet is selected, see the available columns
    output$selectSampleIDCol <- renderUI({
      selectInput("selectSampleIDCol",
                  "Select a column to be used as sample ID:", 
                  choices = rv$uniqueCols,
                  selected = rv$uniqueCols[1])
    })
  } else {
    # When a sheet is selected, see the available columns
    output$selectSampleIDCol <- renderUI({
      selectInput("selectSampleIDCol",
                  "Select a column to be used as sample ID:", 
                  choices = rv$dataColNames,
                  selected = rv$dataColNames[1])
    })
  }
})


observeEvent(input$updateDataSelect, {
  
  # Check file extension
  
  # Get available sheets in the upload if excel
  currSheets = excel_sheets(rv$fileUploadPath)
  sheetCount = 1
  for (a in 1:length(currSheets)){
    currCurr = currSheets[a]
    if (input$selectSheet != currCurr){
      sheetCount = sheetCount + 1
      
    } else {
      break
    }
  }
  # output$selectSheet <- renderUI({
  #   
  #   selectInput("selectSheet",
  #             "Select Excel sheet to upload",
  #             choices = currSheets,
  #             selected = currSheets[1])
  # })
  
  print(paste0("datapath:", rv$fileUploadPath))
  df = read_xlsx(rv$fileUploadPath, sheetCount)
  rv$df = df
  
  dataColNames = colnames(df)
  colIsUnique = c()
  uniqueCols = c()
  
  # Get total number of rows
  numTotalEntries = dim(df)[1]
  # Find columns that contain all unique entries
  for (i in 1:length(dataColNames)){
    currColName = dataColNames[i]
    currCol = df[, currColName]
    uniqueEntries = unique(currCol)
    numUniqueEntries = dim(uniqueEntries)[1]
    
    if (numUniqueEntries == numTotalEntries){
      colIsUnique = c(colIsUnique, "TRUE")
      uniqueCols = c(uniqueCols, currColName)
    } else {
      colIsUnique = c(colIsUnique, "FALSE")
      
    }
    print(paste0("___________________________________"))
    print(paste0("COLUMN AT [", i, "]:", currColName))
    print(paste0("DIM unique entries:", dim(uniqueEntries)))
  }
  
  # Save to reactive variable
  rv$uniqueCols = uniqueCols
  rv$dataColNames = dataColNames
  
  print(paste0("COLISUNIQUE?:", colIsUnique))
  
  if (rv$addUniqueColAnyway == FALSE){
    # When a sheet is selected, see the available columns
    output$selectSampleIDCol <- renderUI({
      selectInput("selectSampleIDCol",
                  "Select a column to be used as sample ID:", 
                  choices = uniqueCols,
                  selected = uniqueCols[1])
    })
  } else {
    # When a sheet is selected, see the available columns
    output$selectSampleIDCol <- renderUI({
      selectInput("selectSampleIDCol",
                  "Select a column to be used as sample ID:", 
                  choices = dataColNames,
                  selected = dataColNames[1])
    })
  }
  
  
  # Find numeric cols
  nums <- unlist(lapply(df, is.numeric), use.names = FALSE)
  numData_colnames = colnames(df[, nums])
  
  output$selectNumericCol <- renderUI({
    selectInput("selectNumericCol",
                "Select a numeric column to import:", 
                choices = numData_colnames,
                selected = numData_colnames[1])
  })
  
  output$selectClassCol <- renderUI({
    selectInput("selectClassCol",
                "Select a column containing class assignments:",
                choices = dataColNames,
                selected = dataColNames[1])
  })
  
  # Find unique classes for the current column
  rv$currUniqueClasses = unique(df[, dataColNames[1]])
  output$uniqueClassesOutput <- renderUI({
    selectInput("uniqueClassesOutput", "Available classes: ",
                choices = rv$currUniqueClasses,
                selected = rv$currUniqueClasses[1]
    )
  })
  
  
  # Find the class of each column
  print(paste0("COLUMN CLASSES:" , sapply(df, class)))
  
  output$rawDataTable <- DT::renderDataTable({
    df
  },
  options = list(paging = FALSE)
  )
  
  
  output$numericColsOnly <- DT::renderDataTable(df[, nums])
  
})

observeEvent(input$selectClassCol, {
  rv$selectClassCol = input$selectClassCol
  newUniqueFromCol = unique(rv$df[, rv$selectClassCol])
  numAvailClass = dim(newUniqueFromCol)[1]
  rv$currUniqueClasses = newUniqueFromCol
  
  output$uniqueClassesOutput <- renderUI({
    selectInput("uniqueClassesOutput", 
                paste0("Available classes (", numAvailClass, " Total): "), 
                choices = rv$currUniqueClasses,
                selected = rv$currUniqueClasses[1]
    )
  })
})

def_varNumInputs <- function(n, subid, mode){
  
  output_list = list()
  
  # Get metadata 
  df = rv$df
  nums <- unlist(lapply(df, is.numeric), use.names = FALSE)
  numData_colnames = colnames(df[, nums])
  
  for (i in 1:n){
    id = paste0(subid, i)
    output_list[[i]] = uiOutput(outputId = id)
    
  }
  
  output[[subid]] = renderUI({
    return(output_list)
  })
  
  for (i in 1:n){
    id = paste0(subid, i)
    
    if (mode == "select"){
      
      output[[id]] = renderUI({
        # div(
         selectInput(id,
                    "Select a numeric column to import:",
                    choices = numData_colnames,
                    selected = numData_colnames[1],
                    )
         # tags$head(tags$style(HTML(".selectize-input {height: 100px; width: 500px; font-size: 100px;}")))
         # style = "margin-top:20px"
        # )
      })
      
    } else if (mode == "text"){
      output[[id]] = renderUI({
        div(
        textInput(id, "Enter a name: ", 
                            value = ""),
        style = "margin-top:-3px"
        
        )
      })
      
    } else if (mode == "checkbox"){
      output[[id]] = renderUI({
        div(
        checkboxInput(id, "Show all columns.",
                                    value = FALSE),
        style = "margin-top:58px"
        )
        
      })
    }
  }
  
  
}

observeEvent(input$numDimensions, {
  rv$numDimensions = input$numDimensions
  def_varNumInputs(rv$numDimensions, "selectNumericCol", "select")
  def_varNumInputs(rv$numDimensions, "colRenameInput", "text")
  def_varNumInputs(rv$numDimensions, "myNumColNotHere", "checkbox")
  
  # df = rv$df
  # nums <- unlist(lapply(df, is.numeric), use.names = FALSE)
  # numData_colnames = colnames(df[, nums])
  # 
  # output_list = list()
  # 
  # for (i in 1 : rv$numDimensions){
  #   
  #   
  #   id = paste0("selectNumericCol", i)
  #   # idplus_1 = paste0("colRenameInput", i+1)
  #   # idplus_2 = paste0("myNumColNotHere", i+2)
  #   
  #   # output_list[[i]] = renderUI({
  #   #   selectInput("selectNumericCol",
  #   #               "Select a numeric column to import:", 
  #   #               choices = numData_colnames,
  #   #               selected = numData_colnames[1])
  #   # })
  #   
  #   output_list[[i]] = uiOutput(outputId = id)
  # 
  # }
  # 
  # output$selectNumericCol <- renderUI({
  #   return(output_list)
  # })
  # 
  # for (i in 1:rv$numDimensions){
  #   id = paste0("selectNumericCol", i)
  #   
  #   output[[id]] = renderUI({
  #     selectInput(id,
  #                 "Select a numeric column to import:",
  #                 choices = numData_colnames,
  #                 selected = numData_colnames[1])
  #   })
  #   
  # }
  # 
  
  
  
})



observeEvent(input$selectSampleIDCol, {
  rv$selectSampleIDCol = input$selectSampleIDCol
})


# readFile <- function(DataPath){
#   print(paste0("Datapath:" , DataPath))
#   numberofocc = length(strsplit(DataPath, "\\.")[[1]])
#   filetype = strsplit(DataPath,"\\.")[[1]][numberofocc]
#   
#   print(paste0("filetype:", filetype))
#   # print(paste0("filepath: ", DataPath))
#   if(filetype=="jsp"){
#     data = readLines(DataPath)
#     i.PeaksStart = grep("##DATA=",data)+1
#     i.PeaksEnd = grep("##END=",data)-1
#     PeakList = list(data[i.PeaksStart:i.PeaksEnd])
#     
#     
#   } else if (filetype=="txt"){
#     data = readLines(DataPath)
#     a = NULL
#     
#     if (length(data) > 0){    
#       for(i in 1:length(data)){
#         b = strsplit(data[i],"")[[1]][1]
#         if(is.na(suppressWarnings(as.numeric(b)))){
#           a = c(a,i)
#         } 
#       }
#       if(length(a)>0){
#         data = data[-a]  
#       }
#       PeakList = list(data[1:length(data)])
#     } else {
#       PeakList = NULL
#     }
#     
#   } else if (filetype=="csv"){
#     
#     rdata = readLines(DataPath)
#     data = gsub(",","\t",rdata)
#     PeakList = list(data[1:length(data)])
#     
#   } else if (filetype =="other"){
#     
#     data = readLines(DataPath)
#     for (i in 1:length(data)){
#       df = read.table(textConnection(data[[i]]))
#     }
#     PeakList = df
#   } else if (filetype == "xlsx"){
#     
#     
#   }
#   
#   return(PeakList)
#   
# }