## =============================================================================

# TITLE: sst_GUI_ABOUT.R

# DESCRIPTION: 
    # This program defines the About tab of the DART-MS Search application. 
    # Users can use this tab to find disclaimer and contact information. 

## =============================================================================

    # sst_GUI_ABOUT <- tabPanel(
    #   "About",
    #   
    #   br(),
    #   fluidRow(
    #     id = "MessageRow_About",
    #     DevModeMessage,
    #     DisclaimerMessage,
    #     DisclaimerMessage2,
    #     NIJDisclaimer,
    #     EmailMessage
    #   ),
    #   br(),
    #   
    #   
    # )