# Handles input for text field for a new database name (Builder)
observeEvent(input$sqlNameEntry, {
  # Only continue if text provided
  if (isTruthy(input$sqlNameEntry)){
    # Save input to temp variable
    tempname = input$sqlNameEntry
    # If not .sqlite, add it as extension
    if (!grepl(".sqlite", tempname)){
      tempname = paste0(tempname, ".sqlite")
    }
    # Update reactive variable for name
    db$name = tempname
  } else {
    # If no input is provided, set db$name to default value (Not truthy)
    db$name = "Default_Database.sqlite"
  }
})



openDBConnection <- function(mode){
  # Default name and path of database (DB)
  dbPath = "SQL/"
  
  if (mode == "Build" && isTruthy(db$name)){
    # Use text field entry for DB name
    nameOfDB = db$name
    # Reset the text field once used
    reset("sqlNameEntry")
  } 
  # else if (mode == "Load" && isTruthy(db$Select_SQL_Database)){
  #   # Use dropdown menu selection for DB name
  #   nameOfDB = db$Select_SQL_Database
  # } else if (mode == "Search" && isTruthy(db$Select_SQL_Database_Search)){
  #   nameOfDB = db$Select_SQL_Database_Search
  # } 
  
  # Concatenate path and name
  totalPath = paste0(dbPath, nameOfDB)
  
  # If the DB connection is active
  if (!db$dbEmpty){
    # Close connection
    dbDisconnect(con)
    con <<- NULL
    # reactive variable to show database is empty
    db$dbEmpty = TRUE
  }
  # Proceed with connection if successful disconnect and valid name provided
  if (!isTruthy(con) && isTruthy(nameOfDB)){
    # Params 1,2,3 & 5 are default
    con <<- DBI::dbConnect(RSQLite::SQLite(), user = 'root', password = '',
                           dbname = totalPath, host = 'localhost')
  } else {
    # Display expected error message here (does this ever happen?)
  }
  # Set reactive value to show DB connected 
  db$dbEmpty = FALSE
}



observeEvent(input$submitImport, {
  print(paste0("===================================================="))
  print(paste0("DIM ADD ANTIGEN:", dim(rv$addAntigen)))
  print(paste0("rv$addAntigenCurent:", rv$addAntigen))
  print(paste0("_________________________________________________"))
  print(paste0("rv$addClassCurrent:", rv$addClass))
  print(paste0("DIM ADD ANTIGEN:", dim(rv$addClass)))
  print(paste0("===================================================="))
  
  openDBConnection("Build")
  
  dbWriteTable(con, "rawData", rv$df, append = FALSE, overwrite = TRUE)
  
  # Plot work
  output$firstGraph <- renderPlotly({
    toPlot = rv$df[, unlist(as.character(rv$addAntigen$colSelect))]
    toPlotDF = as.data.frame(toPlot)
    x_var <- paste0(colnames(toPlotDF)[1])
    y_var <- paste0(colnames(toPlotDF)[2])
    
    print(paste0("rv$numDimensions :;, 
                 ,", rv$numDimensions))
    if (rv$numDimensions == 3){
      z_var = paste0(colnames(toPlotDF)[3])
      q <- plot_ly(data = toPlotDF,  
                  x = toPlotDF[[x_var]], y = toPlotDF[[y_var]],
                      z = toPlotDF[[z_var]],
                  type = 'scatter3d')
      
      ggplotly(q, tooltip = c("text"))
      
    } else {
      q <- ggplot(toPlotDF,  
                  aes(x = .data[[x_var]], y = .data[[y_var]])) + 
        geom_point()
      
      ggplotly(q, tooltip = c("text"))
    }
   
   
    
  })
  
  # Check work
  sqlTest = dbGetQuery(con, "SELECT * FROM rawData")
  
  output$rawDataFromSQL <- renderDataTable({
    sqlTest
  })
})
