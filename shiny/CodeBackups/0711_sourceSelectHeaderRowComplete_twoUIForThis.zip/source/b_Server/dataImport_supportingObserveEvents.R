# ==============================================================================
# 
# TITLE: dataImport_supportingObserveEvents.R
#
#                               DESCRIPTION
# This program contains short observeEvents that support the User interface
# relating to data import. 
#
#                             TABLE OF CONTENTS
#       1) FILE UPLOAD
#       2) SELECT EXCEL SHEET
#       3) SELECT SAMPLE ID COLUMN
#       3) CHEFCKBOX FOR SAMPLE ID FILTER
#
# ==============================================================================
# ==============================================================================
# 1) FILE UPLOAD
# ==============================================================================
# This observeEvent allows users to upload one or many files, and updates the
# selectSheet input (if an xlsx upload) to show available sheets to import

observeEvent(input$fileUploadInput, {
  # Get the datapath from the file upload
  datapath = paste0("Data/", input$fileUploadInput[1])
  # Write to reactive variable
  rv$fileUploadPath = datapath
  # Check file extension
  
  # Do the upload
  
  # Get available sheets in the upload if excel
  currSheets = excel_sheets(rv$fileUploadPath)
  
  output$selectSheet <- renderUI({
    selectInput("selectSheet",
                "Select Excel sheet to upload",
                choices = currSheets,
                selected = currSheets[1])
  })
  
})

# ==============================================================================
# 2) SELECT EXCEL SHEET
# ==============================================================================
observeEvent(input$selectSheet, {
  rv$excelSheetSelected = input$selectSheet
  
})

# ==============================================================================
# 3) SELECT SAMPLE ID COLUMN
# ==============================================================================
observeEvent(input$selectSampleIDCol, {
  rv$selectSampleIDCol = input$selectSampleIDCol
})


# ==============================================================================
# 4) CHEFCKBOX FOR SAMPLE ID FILTER
# ==============================================================================
# This observeEvent filters the available columns that can be used for sample ID
# If checked, this checKbox will only show columns where EVERY value is unique.
# If not checked, any column can be used as sample ID but extra processes will
# be required to make every value unique. 

observeEvent(input$addUniqueColAnyway, {
  rv$addUniqueColAnyway = input$addUniqueColAnyway
  
  if (rv$addUniqueColAnyway == FALSE){
    # When a sheet is selected, see the available columns
    output$selectSampleIDCol <- renderUI({
      selectInput("selectSampleIDCol",
                  rui$selectSampleID, 
                  choices = rv$uniqueCols,
                  selected = rv$uniqueCols[1])
    })
  } else {
    # When a sheet is selected, see the available columns
    output$selectSampleIDCol <- renderUI({
      selectInput("selectSampleIDCol",
                  rui$selectSampleID, 
                  choices = rv$dataColNames,
                  selected = rv$dataColNames[1])
    })
  }
})




# 07/11/23 _____________________________________________________________________

observeEvent(input$headerPresentCheck, {
  # Ask user to check (YES) if the header is located in an abnormal location
  #         Ex) A header that is not in the first row
  # Ask user to uncheck (NO) if no header is present or the header is row 1
  rv$headerPresent = input$headerPresentCheck
  
})

observeEvent(input$specifyHeaderRow, {
  
  rv$headerRow = input$specifyHeaderRow
})















