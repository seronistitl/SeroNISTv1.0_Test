## =============================================================================

# TITLE: sst_GUI_DBB.R

# DESCRIPTION: 
# This program defines the UI for the Database builder portion of the WDIT.
# Users can use this tab to select data to incorporate into the SQL database.

## =============================================================================

sst_GUI_DBB <- tabPanel(
  "Database Builder",
  br(), br(), br(), br(),
  
  # Side bar for file inputs and DartSearch (trigger_butotn.R eventReactive)
  sidebarPanel(shinyjs::useShinyjs(),
               id = "side-panel",
               tabsetPanel(id = "tabSwitch_DB",
                           tabPanel("Build", id = "BuildTab",
                                    br(),
                                    textInput("newdbname", label = "Enter a name for the database:",
                                              placeholder = "Database name"),
                                    div(p(HTML("Choose an excel spreadsheet to build the library from."
                                    )),style = "color:black;font-size:10pt"),
                                    # div(selectInput("Select_Master_Excel",
                                    #                 "Master File: ",
                                    #                 choices = master_files,
                                    #                 selected = master_files[1]),
                                    #     style = "color:black"),
                                    selectInput("Select_Folder",
                                                "Select Directory for Spectral Data: ",
                                                choices = data_directory,
                                                selected = data_directory[1]),
                                    sliderInput("resolution", label = "Select a resolution for similarity computations:",
                                                min = 0.000,
                                                max = 0.01,
                                                step = 0.0005,
                                                value = 0.005),
                                    sliderInput("noiseThreshold", "Select a noise threshold for similarity computations: ",
                                                min = 0, 
                                                max = 10,
                                                step = 1,
                                                value = 3),
                                    sliderInput("rangeSliderMz", "Select an m/z range for similarity computations:",
                                                min = 0,
                                                max = 1000,
                                                step = 1,
                                                value = c(0,1000)
                                                ),
                                    sliderInput("simThresh", label = "Select a cutoff threshold for compatible spectra detection: ",
                                                min = 0,
                                                max = 100,
                                                step = 1,
                                                value = 40
                                    ),
                                    
                                    # radioButtons("toggle_Traditional", "Output Type: ",
                                    #              choices = c("Traditional", "Collapsed"),
                                    #              selected = "Traditional", inline = TRUE),
                                    
                                    br(), br(),
                                    # Action button DartSearch prompts trigger_button.R
                                    actionButton("Build", "Build Library",
                                                 style = 'padding:10px; font-size:120%;
             color: white; background-color: #3E668E;
             border-color: #2C3E50'),
                                    
                                    br(), br(),
                                    actionButton("BuildRDS", "Build RDS",
                                                 style = 'padding:10px; font-size:120%;
             color: white; background-color: #3E668E;
             border-color: #2C3E50'),
                           ) # End tab panel
               )
               
  ),
  # Next main panel
  mainPanel(
    fluidRow(id = "SQLFileInfo",
             column(8, DT::dataTableOutput("FileDirAfterFinishBuild")),
             column(8, DT::dataTableOutput("GroupDirSQL"))
             # column(8, DT::dataTableOutput("prelimA")),
             # column(8, DT::dataTableOutput("prelimB"))
             
             
    ),
    
    # Unique names table populates here
    fluidRow(id = "uniqueNames",
             column(8, DT::dataTableOutput("uniqueNameSQL_Builder", width = "2000px")),
             column(8, DT::dataTableOutput("Hist0.1"))
             
    ),
  )
  
  
)