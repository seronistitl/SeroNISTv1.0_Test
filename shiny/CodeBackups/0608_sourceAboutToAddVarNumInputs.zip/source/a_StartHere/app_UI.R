## =============================================================================

# TITLE: appUI.R

# DESCRIPTION: 

## =============================================================================

# Load GUI programs
# source('source/b_UI/sst_GUI_DST.R')   # Database Search
source('source/b_UI/sst_GUI_Viewer.R')   # Database Search
# source('source/b_UI/sst_GUI_DBB.R')   # Database Builder
# source('source/GUI/sst_GUI_ABOUT.R') # Disclaimer messages and contact

# Package appUI 
appUI <- shinyUI({
  # Define image banner, style, title, and navbarPage
  fixedPage(theme=shinytheme("flatly"),
            shinyjs::useShinyjs(),
            list(tags$head(HTML('<link rel="icon", href="DIT-LOGO.png",
                                  type="image/png" />'))),
            div(style="padding: 1px 0px; width: '100%'", 
                titlePanel(
                  title="",windowTitle="Classification Tool")),
            # div(p(img(src="DIT-Banner.png",width="70%")),align="center"),
            navbarPage(" ",
                       # sst_GUI_DST,
                       sst_GUI_Viewer
                       # sst_GUI_DBB
            )
  )
})