# ## =============================================================================
# 
# # TITLE: global.R
# 
# # DESCRIPTION: 
# # The purpose of this program is to define and load variables that remain 
# # constant throughout the shiny experience before the UI and server are called
# 
# 
# #                             TABLE OF CONTENTS: 
# #       1) LOAD FUNCTIONS
# #       2) INIT GLOBAL VARIABLES
# #       3) INIT REACTIVE VARIABLES
# #       4) VARIABLES FOR SQL 
# 
# ## =============================================================================
# 
# ## =============================================================================
# ## 1) LOAD FUNCTIONS
# ## =============================================================================
# # Import asm functions here
# source("source/Functions/asm-clc.R")
# source("source/Functions/asm_Listcreator_v1.02.R")
# source("source/Functions/asm-spec2dt.R")
# source("source/Functions/asm-specImport.R")
# source("source/Functions/asm-bpNormalizer.R")
# source("source/Functions/asm_sst_head2tail.R")
# 
# # color test
# source("source/colorTest.R")
# 
# # Import cpp functions
# sourceCpp("source/ServerFunctions/RCPP/Functions/asm_LibrarySearch_CPP.cpp") 
# sourceCpp("source/ServerFunctions/RCPP/asm_LibrarySearch.cpp") 
# sourceCpp("source/ServerFunctions/RCPP/sst_pcaAlignment.cpp") 
# 
# 
# # Clear console using helper function
# clc()
# 
# ## =============================================================================
# ## 2) INIT GLOBAL VARIABLES
# ## =============================================================================
# # File types accepted
# query_file_types = c(".txt",".jsp",".csv");
# 
# # Find master excel sheets available
# master_files = list.files("./MasterFiles",pattern=".xlsx")
# dataFiles = list.files("./Data", pattern = ".sqlite")
data_directory = list.files("./Data")
# data_directory = list.dirs("./Data", recursive = FALSE)


## =============================================================================
## 3) INIT REACTIVE VARIABLES
## =============================================================================
# Init reactive values for shiny gui use
rv <- reactiveValues()

# db primarily used for search history
db <- reactiveValues()

# # Evaluator settings
# ev <- reactiveValues()
# # commit_db contains fields of the current search selection
# commit_db = reactiveValues() 
# # Create reactive variable for UNT viewer tab 
# untviewer = reactiveValues()
# evtviewer = reactiveValues()
# rvUpload = reactiveValues()
# 
## =============================================================================
## 4) VARIABLES FOR SQL
## =============================================================================
# Reset the database connection variable
con <<- NULL
# Set database to empty on start
db$dbEmpty = TRUE
