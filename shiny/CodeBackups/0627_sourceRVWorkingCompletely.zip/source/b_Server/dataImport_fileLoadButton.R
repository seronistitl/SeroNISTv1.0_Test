# ==============================================================================
# 
# TITLE: dataImport_fileLoadButton.R
#
#                               DESCRIPTION
# This button contains the large observeEvent that responds to the user pressing
# the "Load" button to begin data import. Users must first upload a file and 
# select an excel sheet before pressing. A table showing raw data is rendered, 
# as well as UI inputs to allow users to select and import data.
# 
#                             TABLE OF CONTENTS
#       1) IMPORT DATA
#               i) Check excel sheet upload  
#       2) DEFINE SAMPLE ID AVAILABLE COLUMNS
#               i) Find columns that contain all unique entries
#               ii) Render sample ID dropdown menu
#       3) DEFINE CLASS AVAILABLE COLUMNS
#       4) RENDER RAW DATATABLE
#               i) Set sigfigs for numeric columns
#               ii) Raw datatable output
#
# ==============================================================================


observeEvent(input$updateDataSelect, {
  # ============================================================================
  # 1) IMPORT DATA
  # ============================================================================
  # Only continue if file(s) uploaded 
  req(isTruthy(input$fileUploadInput))
  
  # Check file extension
  
  # i) Check excel sheet upload ________________________________________________
  currSheets = excel_sheets(rv$fileUploadPath)
  sheetCount = 1
  # Loop through all available sheets
  for (a in 1:length(currSheets)){
    currCurr = currSheets[a]
    # If the current sheet isn't the one currently selected
    if (input$selectSheet != currCurr){
      # increment counter
      sheetCount = sheetCount + 1
    } else {
      # If found currently selected sheet, exit with current sheet count
      break
    }
  } # end a loop
  
  # Read in actual data to data frame df
  df = read_xlsx(rv$fileUploadPath, sheetCount)
  # Save df reactively
  rv$df = df
  
  # ============================================================================
  # 2) DEFINE SAMPLE ID AVAILABLE COLUMNS
  # ============================================================================
  # Initialize data structures for unique columns
  colIsUnique = c()
  uniqueCols = c()
  
  # Save column names of import
  dataColNames = colnames(df)
  # Get total number of rows
  numTotalEntries = dim(df)[1]
  
  # i) Find columns that contain all unique entries ____________________________
  # Loop through all columns
  for (i in 1:length(dataColNames)){
    # Get current column
    currColName = dataColNames[i]
    currCol = df[, currColName]
    # Get number of unique entries in current column i
    uniqueEntries = unique(currCol)
    numUniqueEntries = dim(uniqueEntries)[1]
    
    # See if the column is valid for a sample ID column (every value is)
    if (numUniqueEntries == numTotalEntries){
      colIsUnique = c(colIsUnique, "TRUE")
      # Store list of all entirely unique columns
      uniqueCols = c(uniqueCols, currColName)
    } else {
      colIsUnique = c(colIsUnique, "FALSE")
    }
  } # end i loop
  
  # Save to reactive variable
  # All columns that are entirely unique
  rv$uniqueCols = uniqueCols
  # all column names
  rv$dataColNames = dataColNames
  
  # ii) render sample ID dropdown menu _________________________________________
  # If filter is on
  if (rv$addUniqueColAnyway == FALSE){
    uniqueCols = c(uniqueCols, "a", "b")
    # When a sheet is selected, see the available columns
    output$selectSampleIDCol <- renderUI({
      div(tags$head(
        # Highlight options for selectInput
        tags$style(HTML("
        .option[data-value=a] {
          background: red !important;
          color: white !important;
        }
        .option[data-value=b] {
          background: green !important;
          color: white !important;
        }
  "))
      ),
      # Dropdown menu for selecting sample ID column
      selectInput("selectSampleIDCol",
                  "Select a column to be used as sample ID:", 
                  choices = uniqueCols,
                  selected = uniqueCols[1])
      ) # end div
    })
  } else {
    # When a sheet is selected, see the available columns
    output$selectSampleIDCol <- renderUI({
      selectInput("selectSampleIDCol",
                  "Select a column to be used as sample ID:", 
                  choices = dataColNames,
                  selected = dataColNames[1])
    })
  } # end conditional block
  
  # ============================================================================
  # 3) DEFINE CLASS AVAILABLE COLUMNS
  # ============================================================================
  output$selectClassCol <- renderUI({
    selectInput("selectClassCol",
                "Select a column containing class assignments:",
                choices = dataColNames,
                selected = dataColNames[1])
  })
  
  # Find unique classes for the current column
  rv$currUniqueClasses = unique(df[, dataColNames[1]])
  
  # render dropdown menu for classes
  output$uniqueClassesOutput <- renderUI({
    selectInput("uniqueClassesOutput", "Available classes: ",
                choices = rv$currUniqueClasses,
                selected = rv$currUniqueClasses[1]
    )
  })
  
  # ============================================================================
  # 4) RENDER RAW DATATABLE
  # ============================================================================
  # i) Set sigfigs for numeric columns _________________________________________
  nums <- unlist(lapply(df, is.numeric), use.names = FALSE)
  numData_colnames = colnames(df[, nums])
  numsInt = unlist(lapply(df, is.integer), use.names = FALSE)
  
  df2 = sapply(df,is.numeric)
  ints2<-sapply(df[,df2],function(col){return((sum(col%%1)==0))})
  
  
  
  # ii) Raw datatable output ___________________________________________________
  output$rawDataTable <- DT::renderDataTable({
    # For numeric columns (in df2), set sigfigs depending on double vs. integer
    df[, df2] = df[, df2]  %>%
      mutate(across(where(
        function(x) is.double(x) 
        & !sapply(!sum(x%%1)==0, isFALSE)),
        .fns = function(x) {format(round(x, 4), nsmall = 4)}))
    
    # return full dataframe (all)
    df
    
    # Other alternatives for sigfigs
    # df  %>%
    #   mutate(across(where(function(x) is.double(x) & !sum(x%%1)==0),
    #                 .fns = function(x) {format(round(x, 4), nsmall = 4)}))
    # 
    # mutate(across(where(function(x) is.numeric(x) & !is.integer(x)), 
    # sprintf, fmt = '%.2f'))
  }, 
  filter = "top", # search box
  selection = "multiple", 
  extensions = c("FixedHeader", "FixedColumns"),
  server = FALSE, # disable this for numeric sort
  options = list(
    paging = FALSE,
    scrollX = TRUE,
    scrollY = "500px",
    fixedHeader = T,
    fixedColumns = list(leftColumns = 1))
  )
}) # end renderDataTable
