
observeEvent(input$selectSheet, {
  rv$excelSheetSelected = input$selectSheet
  
})


observeEvent(input$selectSampleIDCol, {
  rv$selectSampleIDCol = input$selectSampleIDCol
})


observeEvent(input$fileUploadInput, {
  # Get the datapath from the file upload
  datapath = paste0("Data/", input$fileUploadInput[1])
  # Write to reactive variable
  rv$fileUploadPath = datapath
  # Check file extension
  
  # Do the upload
  
  # Get available sheets in the upload if excel
  currSheets = excel_sheets(rv$fileUploadPath)
  
  output$selectSheet <- renderUI({
    selectInput("selectSheet",
                "Select Excel sheet to upload",
                choices = currSheets,
                selected = currSheets[1])
  })
  
})





observeEvent(input$addUniqueColAnyway, {
  rv$addUniqueColAnyway = input$addUniqueColAnyway
  
  if (rv$addUniqueColAnyway == FALSE){
    # When a sheet is selected, see the available columns
    output$selectSampleIDCol <- renderUI({
      selectInput("selectSampleIDCol",
                  "Select a column to be used as sample ID:", 
                  choices = rv$uniqueCols,
                  selected = rv$uniqueCols[1])
    })
  } else {
    # When a sheet is selected, see the available columns
    output$selectSampleIDCol <- renderUI({
      selectInput("selectSampleIDCol",
                  "Select a column to be used as sample ID:", 
                  choices = rv$dataColNames,
                  selected = rv$dataColNames[1])
    })
  }
})


observeEvent(input$updateDataSelect, {
  
  # Check file extension
  
  # Get available sheets in the upload if excel
  currSheets = excel_sheets(rv$fileUploadPath)
  sheetCount = 1
  for (a in 1:length(currSheets)){
    currCurr = currSheets[a]
    if (input$selectSheet != currCurr){
      sheetCount = sheetCount + 1
      
    } else {
      break
    }
  }
  # output$selectSheet <- renderUI({
  #   
  #   selectInput("selectSheet",
  #             "Select Excel sheet to upload",
  #             choices = currSheets,
  #             selected = currSheets[1])
  # })
  
  df = read_xlsx(rv$fileUploadPath, sheetCount)
  rv$df = df
  
  dataColNames = colnames(df)
  colIsUnique = c()
  uniqueCols = c()
  
  # Get total number of rows
  numTotalEntries = dim(df)[1]
  # Find columns that contain all unique entries
  for (i in 1:length(dataColNames)){
    currColName = dataColNames[i]
    currCol = df[, currColName]
    uniqueEntries = unique(currCol)
    numUniqueEntries = dim(uniqueEntries)[1]
    
    if (numUniqueEntries == numTotalEntries){
      colIsUnique = c(colIsUnique, "TRUE")
      uniqueCols = c(uniqueCols, currColName)
    } else {
      colIsUnique = c(colIsUnique, "FALSE")
      
    }
  }
  
  # Save to reactive variable
  rv$uniqueCols = uniqueCols
  rv$dataColNames = dataColNames
  
  
  if (rv$addUniqueColAnyway == FALSE){
    uniqueCols = c(uniqueCols, "a", "b")
    # When a sheet is selected, see the available columns
    output$selectSampleIDCol <- renderUI({
      div(tags$head(
        tags$style(HTML("
        .option[data-value=a] {
          background: red !important;
          color: white !important;
        }
        .option[data-value=b] {
          background: green !important;
          color: white !important;
        }
  "))
      ),
      
      selectInput("selectSampleIDCol",
                  "Select a column to be used as sample ID:", 
                  choices = uniqueCols,
                  selected = uniqueCols[1])
      )
    })
  } else {
    # When a sheet is selected, see the available columns
    output$selectSampleIDCol <- renderUI({
      selectInput("selectSampleIDCol",
                  "Select a column to be used as sample ID:", 
                  choices = dataColNames,
                  selected = dataColNames[1])
    })
  }
  
  
  # Find numeric cols
  nums <- unlist(lapply(df, is.numeric), use.names = FALSE)
  numData_colnames = colnames(df[, nums])
  
  output$selectNumericCol <- renderUI({
    selectInput("selectNumericCol",
                "Select a numeric column to import:", 
                choices = numData_colnames,
                selected = numData_colnames[1])
  })
  
  output$selectClassCol <- renderUI({
    selectInput("selectClassCol",
                "Select a column containing class assignments:",
                choices = dataColNames,
                selected = dataColNames[1])
  })
  
  # Find unique classes for the current column
  rv$currUniqueClasses = unique(df[, dataColNames[1]])
  output$uniqueClassesOutput <- renderUI({
    selectInput("uniqueClassesOutput", "Available classes: ",
                choices = rv$currUniqueClasses,
                selected = rv$currUniqueClasses[1]
    )
  })
  
  
  # Find the class of each column
  output$rawDataTable <- DT::renderDataTable({
    df
  },
  options = list(paging = FALSE)
  )
  
  
  output$numericColsOnly <- DT::renderDataTable(df[, nums])
  
})

observeEvent(input$selectClassCol, {
  rv$selectClassCol = input$selectClassCol
  newUniqueFromCol = unique(rv$df[, rv$selectClassCol])
  numAvailClass = dim(newUniqueFromCol)[1]
  rv$currUniqueClasses = newUniqueFromCol
  
  output$uniqueClassesOutput <- renderUI({
    selectInput("uniqueClassesOutput", 
                paste0("Available classes (", numAvailClass, " Total): "), 
                choices = rv$currUniqueClasses,
                selected = rv$currUniqueClasses[1],
                multiple = TRUE
    )
  })
})


observeEvent(input$numDimensions, {
  rv$numDimensions = input$numDimensions
  
  
  df = rv$df
  nums <- unlist(lapply(df, is.numeric), use.names = FALSE)
  numData_colnames = colnames(df[, nums])
  
  output_list = list()
  
  for (i in 1 : rv$numDimensions){
    id = paste0("selectNumericCol", i)
    idplus_1 = paste0("colRenameInput", i)
    idplus_2 = paste0("removeDim_", i)
    
    if (i == 1){
      output_list[[i]] = 
        div(
          fluidRow(
            column(1, 
                   div(i,
                       style = "margin-top:35px")
            ),
            column(5, 
                   uiOutput(outputId = id)
            ),
            column(5, 
                   uiOutput(outputId = idplus_1) 
            ),
            column(1,
                   div(
                     uiOutput(outputId = idplus_2),
                     style = "margin-top: -30px; padding: 15px;"
                   )
            )
          ), 
          style = "margin-top:-50px"
          
        ) # End div
    } else {
      output_list[[i]] = 
        div(
          fluidRow(
            column(1, 
                   div(i,
                       style = "margin-top:35px")
            ),
            column(5, 
                   uiOutput(outputId = id)
            ),
            column(5, 
                   uiOutput(outputId = idplus_1) 
            ),
            column(1,
                   div(
                     uiOutput(outputId = idplus_2),
                     style = "margin-top: -30px; padding: 15px;"
                   )
            )
          ), 
        ) # End div
    }
  }
  
  output$rowsOfData <- renderUI({
    if (rv$numDimensions > 3){
      div(output_list, 
          style = "padding: 45px; height:250px; overflow-y: scroll; overflow-x: hidden;"
      )
    } else if (rv$numDimensions > 2) {
      div(output_list, 
          style = "padding: 45px; height:300px;"
      )
    } else if (rv$numDimensions > 1){
      div(output_list, 
          style = "padding: 45px; height:200px;"
      )
    } else {
      div(output_list, 
          style = "padding: 45px; height:100px;"
      )
    }
  })
  
  for (i in 1:rv$numDimensions){
    id = paste0("selectNumericCol", i)
    idplus_1 = paste0("colRenameInput", i)
    idplus_2 = paste0("removeDim_", i)
    
    output[[id]] = renderUI({
      selectInput(id,
                  "",
                  choices = numData_colnames,
                  selected = numData_colnames[1])
    })
    
    output[[idplus_1]] = renderUI({
      div(
        textInput(idplus_1, "",
                  value = ""),
        style = "margin-top:-5px"
      )
    })
    
    output[[idplus_2]] = renderUI({
      div(
        actionButton(idplus_2,
                     label = HTML("<span class='small'><i class=
                                       'glyphicon glyphicon-remove'
                                       ></i></span>")),
        style = "margin-top:30px"
      )
    })
  }
})



# ==============================================================================

observeEvent(input$addClassBtn, {
  req(rv$addedClasses < 10 && isTruthy(input$uniqueClassesOutput))
  
  rv$addedClasses = rv$addedClasses + 1
  rv$classIndex = c(rv$classIndex, 
                    paste(input$uniqueClassesOutput, collapse = "; ")
                          )
  
  output_list = list()
  
  for (i in 1:rv$addedClasses){
    
    
    id = paste0("chosenClassesTxt_", i)
    idplus_1 = paste0("numRowsForClass_", i)
    idplus_2 = paste0("renameSelectedClass_", i)
    idplus_3 = paste0("xRemoveClass_", i)
    
    output_list[[i]] = 
      div(fluidRow(
        column(1, 
               div(
                 i, 
                 style = ""
                 
                 # style = "margin-top:0px; padding: 35px;"
               )
        ),
        column(4, 
               div(
                 textOutput(outputId = id),
                 style = ""
                 # style = "margin-top:25px; padding: 0px;"
               )
        ),
        column(1, 
               div(
                 textOutput(outputId = idplus_1),
                 style = ""
                 
                 # style = "margin-top: 20px; padding: 15px;"
               )
        ),
        column(5, 
               div(
                 uiOutput(outputId = idplus_2),
                 style = "margin-top: -40px;"
               )
        ),
        column(1,
               div(
                 uiOutput(outputId = idplus_3),
                 # style = "",
                 
                 style = "margin-top: -45px; padding: 20px;"
               )
        )
      ),
      br()
      
      )
    
    
    
  }
  
  output$rowsOfClasses <- renderUI({
    if (rv$addedClasses > 3){
      div(output_list, 
          style = "padding: 45px; height:250px; overflow-y: scroll; overflow-x: hidden;"
      )
    } else if (rv$addedClasses > 2) {
      div(output_list, 
          style = "padding: 45px; height:300px;"
      )
    } else if (rv$addedClasses > 1){
      div(output_list, 
          style = "padding: 45px; height:200px;"
      )
    } else {
      div(output_list, 
          style = "padding: 45px; height:100px;"
      )
    }
  })
  
  print(paste0("Rv$ClassIndex:", rv$classIndex))
  
  
  for (i in 1:rv$addedClasses){
    local({
      i <- i
      
    id = paste0("chosenClassesTxt_", i)
    idplus_1 = paste0("numRowsForClass_", i)
    idplus_2 = paste0("renameSelectedClass_", i)
    idplus_3 = paste0("xRemoveClass_", i)
    
    print(paste0("ChosenText ID at [", i, "]:", id))
    print(paste0("rv$addedClass at [", i, "]:", rv$classIndex[i]))
    print(paste0("rv$addedClass at [[", i, "]]:", rv$classIndex[[i]]))
    
    output[[id]] = renderText({
      rv$classIndex[[i]]
      
    })
    output[[idplus_1]] = renderText({
      5
      
    })
    output[[idplus_2]] = renderUI({
      textInput(idplus_2, label = "", value = "")
    })
    
    
    output[[idplus_3]] = renderUI({
      actionButton(idplus_3,
                   label = HTML("<span class='small'><i class=
                                       'glyphicon glyphicon-remove'
                                       ></i></span>"))
    })
    
    }) # End local
  }
  
  
})



# readFile <- function(DataPath){
#   print(paste0("Datapath:" , DataPath))
#   numberofocc = length(strsplit(DataPath, "\\.")[[1]])
#   filetype = strsplit(DataPath,"\\.")[[1]][numberofocc]
#   
#   print(paste0("filetype:", filetype))
#   # print(paste0("filepath: ", DataPath))
#   if(filetype=="jsp"){
#     data = readLines(DataPath)
#     i.PeaksStart = grep("##DATA=",data)+1
#     i.PeaksEnd = grep("##END=",data)-1
#     PeakList = list(data[i.PeaksStart:i.PeaksEnd])
#     
#     
#   } else if (filetype=="txt"){
#     data = readLines(DataPath)
#     a = NULL
#     
#     if (length(data) > 0){    
#       for(i in 1:length(data)){
#         b = strsplit(data[i],"")[[1]][1]
#         if(is.na(suppressWarnings(as.numeric(b)))){
#           a = c(a,i)
#         } 
#       }
#       if(length(a)>0){
#         data = data[-a]  
#       }
#       PeakList = list(data[1:length(data)])
#     } else {
#       PeakList = NULL
#     }
#     
#   } else if (filetype=="csv"){
#     
#     rdata = readLines(DataPath)
#     data = gsub(",","\t",rdata)
#     PeakList = list(data[1:length(data)])
#     
#   } else if (filetype =="other"){
#     
#     data = readLines(DataPath)
#     for (i in 1:length(data)){
#       df = read.table(textConnection(data[[i]]))
#     }
#     PeakList = df
#   } else if (filetype == "xlsx"){
#     
#     
#   }
#   
#   return(PeakList)
#   
# }