## =============================================================================

# TITLE: sst_GUI_Viewer.R

# DESCRIPTION: 
# This program defines the UI for the Database builder portion of the WDIT.
# Users can use this tab to select data to incorporate into the SQL database.

## =============================================================================

sst_GUI_Viewer <- tabPanel(
  "Classification Tool",
  br(), br(),
  
  sidebarPanel(shinyjs::useShinyjs(),
               id = "startingPanel", width = 12,
               tabsetPanel(id = "tabSwitch_startPanel",
                           tabPanel("Import",
                                    br(),
                                    # bsTooltip(id = "fileUploadInput", title = "This is an input", 
                                    #           placement = "left", trigger = "hover"),
                                    # addTooltip(session, id = "someInput", title = "This is an input.",
                                    #            placement = "left", trigger = "hover") # For server
                                    fileInput("fileUploadInput",
                                              "Upload a file: "),
                                    
                                    fluidRow(
                                      column(6, 
                                             uiOutput("selectSheet"),
                                             bsTooltip(id = "selectSheet", title = "This is an input!!", 
                                                       placement = "left", trigger = "hover"),
                                      ),
                                      column(6, br(),
                                             actionButton("updateDataSelect", "Load")
                                      )),
                                    
                                    fluidRow(
                                      column(6,  uiOutput("selectSampleIDCol")),
                                      # column(4, br(),
                                      #        checkboxInput("noUniqueCol", "No sample ID column to add. Generate one during import.",
                                      #                      value = FALSE)),
                                      column(6, br(),
                                             checkboxInput("addUniqueColAnyway", "Display only compatible columns"))
                                    ),
                                    
                                    
                                    # Numeric import row
                                    fluidRow(
                                      column(6, 
                                             selectInput("numDimensions", "Select number of antigens to analyze", 
                                                         choices = seq(1,20),
                                                         selected = 1)
                                      ), 
                                      column(3, 
                                             checkboxInput("showNumeric_inDataImport",
                                                           "Display only numeric columns",
                                                           value = FALSE),
                                      ),
                                      column(3, 
                                             checkboxInput("autoPopulateNumeric",
                                                           "Autopopulate antigen names",
                                                           value = FALSE))
                                    ),
                                    br(),
                                    fluidRow(
                                      # column(2, 
                                      HTML("<span style=\"display:inline-block; width: 20px;\"></span>
                                      <b>Antigen #</b>
                                      <span style=\"display:inline-block; width: 45px;\"></span>
                                      <b>Select antigen column</b>
                                      <span style=\"display:inline-block; width: 270px;\"></span>
                                           <b>Enter antigen name</b>
                                           <span style=\"display:inline-block; width: 285px;\"></span>
                                           <b>Remove</b>
                                           "),
                                      
                                      # ),
                                      # column(5, HTML("<b>Select antigen column</b>")),
                                      # column(5, HTML("<b>Antigen name</b>")),
                                      div(
                                        
                                        uiOutput("rowsOfData")
                                        # style = "padding: 45px; height:100px;"
                                        # style = "padding: 45px; height:300px; overflow-y: scroll; overflow-x: hidden;",
                                      )
                                    ),
                                    br(), 
                                    # Class selection
                                    fluidRow(
                                      column(6, 
                                             uiOutput("selectClassCol"),
                                      ),
                                      column(3, 
                                             checkboxInput("useAllAvailClasses", 
                                                           "Auto populate using all classes",
                                                           value = FALSE)
                                      ),
                                      column(3, 
                                             checkboxInput("useMultiFileClass",
                                                           "One class per file (multi-upload)",
                                                           value = FALSE
                                             )
                                      )

                                    ),
                                    fluidRow(
                                      column(6, 
                                             uiOutput("uniqueClassesOutput")
                                      ), 
                                      column(3, 
                                             div(
                                               actionButton("addClassBtn", "Add Class"),
                                               style = "margin-top: 20px;"
                                             )
                                      ),
                                      column(3, 
                                             div(
                                               actionButton("clearClassBtn", "Clear all"),
                                               style = "margin-top: 20px;"
                                             )
                                      )
                                    ),
                                    br(), 
                                    fluidRow(
                                        HTML("<span style=\"display:inline-block; width: 20px;\"></span>
                                      <b>Class #</b>
                                      <span style=\"display:inline-block; width: 45px;\"></span>
                                      <b>Selected Classes</b>
                                      <span style=\"display:inline-block; width: 210px;\"></span>
                                      <b># Rows</b>
                                      <span style=\"display:inline-block; width: 55px;\"></span>
                                           <b>Enter class name</b>
                                             <span style=\"display:inline-block; width: 300px;\"></span> 
                                             <b>Remove</b>"),
                                        
                                      div(
                                        uiOutput("rowsOfClasses"),
                                        # style = "height:300px;",
                                        # style = "height:300px; overflow-y: scroll; overflow-x: hidden;",
                                      )
                                    ),
                                    
                                    br(),
                                    br(),
                                    div(DT::dataTableOutput("rawDataTable"), 
                                        style = "height:500px; overflow-y: scroll;overflow-x: scroll;"),
                                    # DT::dataTableOutput("numericColsOnly")
                           ),
                           
                           tabPanel("Evaluate",
                                    
                           ),
                           tabPanel("Export",
                                    
                           )
               )
  )
  
  
  
  # # Side bar for file inputs and DartSearch (trigger_butotn.R eventReactive)
  # sidebarPanel(shinyjs::useShinyjs(),
  #              id = "side-panel", width = 12,
  #              tabsetPanel(id = "tabSwitch_DB",
  #                          
  #                          # Tab for advanced settings:
  #                          # target_min_ab, target assumption, m/z tolerance (integer or not)
  #                          tabPanel("Viewer",
  #                                   br(), 
  #                                   fluidRow(
  #                                     column(4, 
  #                                            div(style = 'width:250px',
  #                                                div(selectInput("Select_SQL_Database",
  #                                                                "Please select a database: ",
  #                                                                choices = sql_files,
  #                                                                selected = sql_files[1]),
  #                                                    style = "color:black"),
  #                                                # sliderInput("numIndividualFilter",
  #                                                #             "Species displayed must contain at least this many spectra:",
  #                                                #             min = 1, max = 300, 
  #                                                #             step = 1,
  #                                                #             value = 10),
  #                                                
  #                                                br(), 
  #                                                
  #                                                
  #                                                # sliderInput("rangeSlider_viewer", "# Individuals per species:",
  #                                                #             min = 0, max = 315, step = 1,
  #                                                #             value = c(20,315)),
  #                                                # 
  #                                                # 
  #                                                # sliderInput("simScoreSlider_viewer", "Min. intrasample similarity: ",
  #                                                #             min = 0, max = 1, step = 0.05,
  #                                                #             value = 0.50, 
  #                                                # ),
  #                                                
  #                                                
  #                                                br(),
  #                                                # Action button DartSearch prompts trigger_button.R
  #                                                actionButton("Load", "Load Database",
  #                                                             style = 'padding:10px; font-size:120%; color: white;
  #                           background-color: #3E668E; border-color: #2C3E50'), 
  #                                                br(), br()
  #                                            )
  #                                            
  #                                     ), 
  #                                     column(4, 
  #                                            br(),
  #                                            div(style = 'width:250px',
  #                                                # sliderInput("dMinSimSlider_eval", "Outlier Threshold (dMin. Sim.): ", 
  #                                                #             min = 0, max = 100,
  #                                                #             step = 5, value = 5
  #                                                #             ),
  #                                                selectInput("combinedPlotViewerOptions", "Viewer options for heatmap:",
  #                                                            choices = c("[1] Display all spectra",
  #                                                                        "[2] Display only incompatible spectra",
  #                                                                        "[3] Display all compatible spectra",
  #                                                                        "[4] Display compatible spectra (User-selected)", 
  #                                                                        "[5] Display compatible spectra (PAMS-selected)", 
  #                                                                        "[6] Display incompatible spectra (User-selected)",
  #                                                                        "[7] Display incompatible spectra (PAMS-selected)"
  #                                                            ),
  #                                                            selected = "[1] Display all spectra"
  #                                                ),
  #                                                # div(selectInput("manOutlier_eval", "Outlier search options:",
  #                                                #                 choices = c("Exclude outliers from analysis", "Include outliers in analysis"),
  #                                                #                 selected = "Include outliers in analysis"
  #                                                #                 
  #                                                # ), style = 'color:red;'), ## Removed 3/24/23
  #                                                # checkboxInput("dMinSimOutlier_eval", "Exclude dMin. Sim. outliers from heatmap",
  #                                                #               value = FALSE),
  #                                                # checkboxInput("manOutlier_eval", "Exclude manually selected spectra from heatmap"), 
  #                                                
  #                                                
  #                                            ),
  #                                            br()
  #                                     ),
  #                                     column(4,
  #                                            br(),
  #                                            div(style = 'width:250px',
  #                                                fileInput("QuerySpectra", "Upload a query spectra",
  #                                                          multiple = TRUE
  #                                                          # placeHolder = "No file selected",
  #                                                          # accept = query_file_types
  #                                                          
  #                                                          
  #                                                ),
  #                                                actionButton("SearchDB", "Search Database",
  #                                                             style = 'padding:10px; font-size:120%;
  #            color: white; background-color: #3E668E;
  #            border-color: #2C3E50')
  #                                            )
  #                                            
  #                                            # ), 
  #                                     )
  #                                   ), # End fluidrow
  #                                   DT::dataTableOutput("uniqueNameSQL"),
  #                                   actionButton("updateUNTSelections", "Update Selections"),
  #                          ), # End tabPanel "Viewer"
  #                          tabPanel("Evaluator",
  #                                   
  #                                   br(), 
  #                                   fluidRow(
  #                                     column(4, 
  #                                            
  #                                            div(style = 'width:250px',
  #                                                sliderInput("resolutionEval", label = "Select a resolution (m/z) to evaluate:",
  #                                                            min = 0.000,
  #                                                            max = 0.01,
  #                                                            step = 0.0005,
  #                                                            value = 0.005),
  #                                                sliderInput("noiseThresholdEval", "Noise threshold (%): ",
  #                                                            min = 0, 
  #                                                            max = 100,
  #                                                            step = 1,
  #                                                            value = 3),
  #                                                sliderInput("rangeSliderMzEval", "Select an m/z range to evaluate:",
  #                                                            min = 0,
  #                                                            max = 1200,
  #                                                            step = 1,
  #                                                            value = c(0,1000)
  #                                                ),
  #                                                sliderInput("simThreshEval", label = "Select a similarity score threshold (%) for incompatible spectra detection: ",
  #                                                            min = 0,
  #                                                            max = 100,
  #                                                            step = 1,
  #                                                            value = 40
  #                                                )
  #                                                
  #                                            )
  #                                     ), 
  #                                     column(4, 
  #                                           
  #                                            selectInput("similarityFunctionDropdown",
  #                                                        "Select a similarity function: ", 
  #                                                        choices = c("Cosine similarity"),
  #                                                        selected = "Cosine similarity"),
  #                                            
  #                                            selectInput("selectSimilarityMode",
  #                                                        "Select a similarity measure to use: ",
  #                                                        choices = c("Average", "Minimum", "Maximum", "Range", "Std Dev"),
  #                                                        # choices = c("Average"),
  #                                                        selected = "Average"),
  # # fluidRow(
  #   div( align = "left",
  #        actionButton("updateEVTSelections", "Evaluate Selections")),
  #   # div( align = "right", actionButton("updateEVTView", "Update Plots"))
  # # ),
  #                                            # radioButtons("ApplyEvalToAll", 
  #                                            #              "Evaluation range: ",
  #                                            #              choices = c("Apply settings to current tab", "Apply settings to all selected species"),
  #                                            #              selected = "Apply settings to all selected species"
  #                                            # )
  #                                     ), 
  #                                     column(4, 
  #                                            selectInput("evalViewerOptions",
  #                                                        
  #                                                        "Select a display option for evaluator figures: ", 
  #                                                        choices = c("[1] Display all spectra",
  #                                                                    "[2] Display only incompatible spectra",
  #                                                                    "[3] Display all compatible spectra",
  #                                                                    "[4] Display compatible spectra (User-selected)", 
  #                                                                    "[5] Display compatible spectra (PAMS-selected)", 
  #                                                                    "[6] Display incompatible spectra (User-selected)",
  #                                                                    "[7] Display incompatible spectra (PAMS-selected)"
  #                                                        ),
  #                                                        selected = "[1] Display all spectra"
  #                                            ),
  #                                            
  #                                            br(), 
  #                                            div( align = "left", 
  #                                                 actionButton("updateEVPlots", "Update Plots")),
  #                                            
  #                                            br(), br(), br(), br(), br(), br(), br(),br(), 
  #                         
  #                                            
  #                                     )
  #                                   ), # End fluidRow
  #                                   br(),
  #                                   
  #                                   br(), 
  #                                   div(
  #                                     uiOutput("plotUIEval"),
  #                                     style = "width:365px; font-size:10px"),
  #                                   fluidRow(
  #                                     column(6, 
  #                                            tableOutput("currentEvalSettings"),
  #                                            
  #                                     ),
  #                                     column(6, 
  #                                            # tableOutput("currentEvalSumStats"),
  #                                            
  #                                     )
  #                                   ),
  #                                   fluidRow(
  #                                     
  #                                   column(6, 
  #                                   div(textOutput("evaluatorWarning"), 
  #                                       style = "color:red"),
  #                                   div(textOutput("evaluatorWarning_NoiseThreshold"), 
  #                                       style = "color:red"),
  #                                   plotlyOutput("similarityMatrix", height = "450px", width = "450")
  #                                   ),
  #                                   column(6, 
  #                                   # Uncomment this to display all similarity scores not grouped by species
  #                                   # plotlyOutput("simMatrixFreqHistogram", height = "600px", width = "600"),
  #                                   # This displays freqhisto for similarity scores grouped by uniqueID
  #                                   plotlyOutput("sumStatFreqHisto", height = "450px", width = "450"),
  #                                   
  #                                   )
  #                          ),
  #                          br(),
  #                          div(DT::dataTableOutput("individualEvalTable"),
  #                              style = "font-size: 80%; width: 100%"),
  #                          br(),
  #                          div( align = "right", 
  #                               actionButton("updateCheckboxes", 
  #                                            "Update User Incompatible Column")
  #                          )
  #                                   
  #                          ),
  #                          tabPanel("Export",
  #                                   fluidRow(
  #                                     column(6, 
  #                                            br(), 
  #                                            radioButtons("exportFolderNameOptions",
  #                                                         label = "Choose a folder naming option:",
  #                                                         choices = c("Enter a name",
  #                                                                     "Use current date time")
  #                                                         ),
  #                                            br(),
  #                                            textInput("exportFolderNameOption",
  #                                                      "Enter a folder name: "),
  #                                            br(),
  #                                            div(textOutput("invalidFolderNameExportMsg"),
  #                                                textOutput("invalidCharacters"),
  #                                                style= "color:red"),
  #                                            div(textOutput("folderAlreadyExists"),
  #                                                style= "color:orange")
  #                                            
  #                                            
  #                                            
  #                                     ),
  #                                     column(6, 
  #                                            br(), 
  #                                            # selectInput("exportOptions",
  #                                            #             "Select an export option: ", 
  #                                            #             choices = c("[1] Exclude all misfits from export",
  #                                            #                         "[2] Exclude only manual-evaluated misfits from export", 
  #                                            #                         "[3] Exclude only auto-evaluated misfits from export", 
  #                                            #                         "[4] Export only manual-selected misfits",
  #                                            #                         "[5] Export only auto-evaluated misfits",
  #                                            #                         "[6] Export all spectra from selected species"),
  #                                            #             selected = "[1] Exclude all misfits from export"
  #                                            # ),
  #                                            selectInput("exportOptions",
  #                                                        "For the selected species, please choose an export option: ", 
  #                                                        choices = c("[1] Export all compatible spectra",
  #                                                                    "[2] Export all incompatible spectra",
  #                                                                    "[3] Export all spectra",
  #                                                                    "[4] Export compatible spectra (User-selected)", 
  #                                                                    "[5] Export compatible spectra (PAMS-selected)", 
  #                                                                    "[6] Export incompatible spectra (User-selected)",
  #                                                                    "[7] Export incompatible spectra (PAMS-selected)"
  #                                                                    ),
  #                                                        selected = "[1] Export all compatible spectra"
  #                                            ),
  #                                            
  #                                            radioButtons("outputFormatType",
  #                                                         "Select an output format",
  #                                                         choices = c(".txt"),
  #                                                         # choices = c(".txt", ".csv",
  #                                                         # ".xslx", ".sqlite"),
  #                                                         selected = ".txt"),
  #                                            div( align = "right", 
  #                                                 actionButton("exportFiles", 
  #                                                              "Export Selections")
  #                                            )
  #                                     )
  #                                   ),
  #                                   
  #                                   
  #                                   
  #                          )
  #                          
  #              ),
  #              br(), br(),
  # ),
  # # Next main panel
  # mainPanel(
  #   # Unique names table populates here
  #   fluidRow(id = "uniqueNames",
  #            column(8, DT::dataTableOutput("fileDirSQLViewer")),
  #            
  #            
  #            # column(8, plotlyOutput("DMP20")),
  #            # column(8, plotlyOutput("DMP40")),
  #            # column(8, plotlyOutput("DMP60")),
  #            # column(8, plotlyOutput("DMP80")),
  #            
  #   ), # End fluidRow
  # ),
  # mainPanel(
  #   # Plots for builder
  #   fluidRow(id = "BuilderPlotsSQL",
  #            column(5, 
  #                   div(
  #                     uiOutput("plotUISQL"),
  #                     style = "width:365px; font-size:10px"),
  #                   plotlyOutput("LibraryPlotSQL",height="300px", width = "370px"),
  #                   fluidRow(id = "previousNextSelet",
  #                            # column(2, 
  #                            # actionButton("firstButton",
  #                            #              label = HTML("<span class='small'><i class=
  #                            #           'glyphicon glyphicon-chevron-left'
  #                            #           ></i><i class=
  #                            #           'glyphicon glyphicon-chevron-left'
  #                            #           ></i></span>"),
  #                            #              style='width:45px; font-size:60%; margin-left:40px'),
  #                            
  #                            # ),
  #                            # column(2,
  #                            actionButton("previousButton",
  #                                         label = HTML("<span class='small'><i class=
  #                                      'glyphicon glyphicon-chevron-left'
  #                                      ></i> Back</span>"),
  #                                         style='width:60px; font-size:60%; margin-left:5px'
  #                            ),
  #                            # ),
  #                            # column(3, 
  #                            div(textInput("manualPlotSelect", label = "", value = 1),
  #                                tags$style("#manualPlotSelect {font-size:10px;height:35px;width:58px;margin-left:155px;margin-top:-56px}")
  #                                
  #                            ),
  #                            # ),
  #                            # column(1,
  #                            uiOutput("manualPlotSelectEnd", style='font-size:12px; width: 50px; margin-left: 220px; margin-top:-40px'),
  #                            # ),
  #                            # column(2,
  #                            actionButton("nextButton",
  #                                         label = HTML("<span class='small'>Next <i class=
  #                                      'glyphicon glyphicon-chevron-right'
  #                                      ></i></span>"),
  #                                         style='width:60px; font-size:10px;margin-left:265px; margin-top:-40px'
  #                            ),
  #                            # ),
  #                            # column(1, 
  #                            # actionButton("lastButton",
  #                            #              label = HTML("<span class='small'><i class=
  #                            #           'glyphicon glyphicon-chevron-right'
  #                            #           ></i><i class=
  #                            #           'glyphicon glyphicon-chevron-right'
  #                            #           ></i></span>"),
  #                            #              style='width:45px; font-size:60%; margin-left:330px; margin-top:-84px'
  #                            # )
  #                            # )
  #                   )
  #                   
  #                   
  #            ),
  #            column(1),
  #            column(6, plotlyOutput("viewerHeatmap", height = "450px", width = "800"),
  #                   div(textOutput("noHeatMapWarning"),
  #                       style= "color:red")
  #                   )
  #   ),
  #   
  #   
  #   # column(8, plotlyOutput("combinedPlotSQL")),
  # ),
  # mainPanel(
  #   tabsetPanel(id = "combinedPlotsID",
  #               
  #               # Tab for advanced settings:
  #               # target_min_ab, target assumption, m/z tolerance (integer or not)
  #               tabPanel("3D Plot",
  #                        br(), 
  #                        
  #                        actionButton("get3dplot", "Get 3D Plot"),
  #                        
  #                        plotlyOutput("combinedPlotSQL", width = "50px", height = "100px")
  #                        
  #                        
  # 
  #               ), 
  #            tabPanel("PCA",
  #                     br(),
  #                     actionButton('getPCA', 'Get PCA'),
  #                            
  #                     plotlyOutput("selectPCA", width = "50px", height = "100px"))
  #            
  #     
  #   ),
  #   # tags$head(
  #   #   tags$style(
  #   #     HTML("#dashboard{margin-bottom:50px;}")
  #   #   )
  #   # )
  # ), # End mainPanel combined Plots
  
)