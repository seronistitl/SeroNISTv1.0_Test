## =============================================================================

# TITLE: asm_sst_GUI_DST.R

# DESCRIPTION: 
# This program defines the UI for the Data search tab of the DART-MS Search
# software. Users can use this tab to upload query spectra and search the 
# reference libraries, as well as toggle between printer friendly and
# interactive views of the data.

## =============================================================================

sst_GUI_DST <- tabPanel(
  "Search Tool",
  # fluidRow(
  #   
  #   style = "color:black;font-size:12pt",
  #   align = "center"
  # ),
  br(),br(),
  fluidRow(
    id = "textfieldrow",
    column(4, align= "center", id = "fr_1",
           br(),
           radioButtons("toggle_DST", "View: ",
                        choices = c("Interactive", "Reporting"),
                        selected = "Interactive", inline = TRUE
           ),
    ),
    
    column(1, id = "fr_2",
           div(p("Date "),
               style = "height:40px; margin-top:-9px"),
           div(p("Case No."),
               style = "height:40px; margin-top:-9px"),
           div(p("Instrument No."),
               style = "width: 100px; font-size: 14px; height:40px; margin-top:-9px"),
           div(p("Item No."),
               style = "height:40px; margin-top:-9px"),
           
           div(p( "Comments "),
               style = "height:40px; margin-top:-9px"),
    ),
    column(4, id = "fr_3",
           textInput("entry1",
                     label = "", value = "",
                     placeholder = "Date..."),
           tags$style(type="text/css", "#entry1 {height:20px; margin-top:-32px}"),
           textInput("entry3",
                     label = "", value = "",
                     placeholder = "Case No..."),
           tags$style(type="text/css", "#entry3 {height:20px; margin-top:-30px}"),
           textInput("entry2",
                     label = "", value = "",
                     placeholder = "Instrument No..."),
           tags$style(type="text/css", "#entry2 {height:20px; margin-top:-30px}"),
           
           textInput("entry4",
                     label = "", value = "",
                     placeholder = "Item No..."),
           tags$style(type="text/css", "#entry4 {height:20px; margin-top:-30px}"),
           textInput("entry5",
                     label = "", value = "",
                     placeholder = "Comments..."),
           tags$style(type="text/css", "#entry5 {height:20px; margin-top:-30px}"),
           
    ),
  ),
  # Side bar for file inputs and DartSearch (trigger_butotn.R eventReactive)
  sidebarPanel(shinyjs::useShinyjs(),
               id = "dst_sidebar",
               tabsetPanel(id = "tab1",
                           tabPanel("Search", id = "searchTabPanel",
                                    br(), 
                                    div(selectInput("Select_SQL_Database_2",
                                                    "Choose a database to search against:",
                                                    choices = sql_files,
                                                    selected = sql_files[1]),
                                        style = "color:black"),
                                    br(), 
                                    # sliderInput("numResultsToFilter", "Select how many results to display:",
                                    #             min = 1, max = 200, value = 50),
                                    # br(), 
                                    
                                    # fileInput("QuerySpectra", "Upload a query spectra",
                                    #           multiple = TRUE
                                    #           # placeHolder = "No file selected",
                                    #           # accept = query_file_types
                                    #           
                                    #           
                                    # ),
                                    br(), br(), br(),
                                    # Action button DartSearch prompts trigger_button.R
             #                        actionButton("SearchDB", "Search Database",
             #                                     style = 'padding:10px; font-size:120%;
             # color: white; background-color: #3E668E;
             # border-color: #2C3E50')
                           ),
                           tabPanel("Analyze", id = "secondarySearchTabPanel", 
                                    br(),
                                    
                                    uiOutput("CSSRT_numSelections", inline = TRUE),
                                    br(),
                                    
                                    br(),
                                    actionButton("secondarySearchDB", "Search",
                                                 style = 'padding:10px; font-size:120%;
             color: white; background-color: #3E668E;
             border-color: #2C3E50')
                                    
                           )
               )
  ),
  
  mainPanel(
    DT::dataTableOutput("Query"),
    DT::dataTableOutput("rawDataSQL77"),
    DT::dataTableOutput("rawDataSQL88"),
    DT::dataTableOutput("rawDataSQL99"),
    
    
    
    DT::dataTableOutput("rawDataSQL101"),
    column(8, DT::dataTableOutput("cosineSimScoreResults")),
    
    column(8, DT::dataTableOutput("cosineSimScoreResults2")),
    br(), br(),
    column(8, 
           plotlyOutput("head2TailPlot")),
    DT::dataTableOutput("rawDataSQL1000"),
    
    DT::dataTableOutput("rawDataSQL100"),
    DT::dataTableOutput("rawDataSQL102"),
    DT::dataTableOutput("HIST808"),
    DT::dataTableOutput("HIST1000"),
    
    DT::dataTableOutput("HIST1001"),
    
    column(8,     DT::dataTableOutput("Hist30")),
    
  ),
  mainPanel(
    br(), br(), br(),
    column(8,  actionButton('getHmap', 'get heatmap'),
           br(),  plotlyOutput("Histogram")),
  ),
  br(), br(), br(), br(),
  mainPanel(
    br(), br(), br(),
    # column(8, actionButton('getPCA', 'get PCA'),
    #        DT::dataTableOutput("NearestRawData0"),
    #        
    #        DT::dataTableOutput("NearestRawData"),
    #        DT::dataTableOutput("NearestRawData2"),
    #        DT::dataTableOutput("NearestRawData3"),
    #        
    #        
    #        plotlyOutput("selectPCA")
    # )
  ),
  br(), br(), br()
  
  
  
)