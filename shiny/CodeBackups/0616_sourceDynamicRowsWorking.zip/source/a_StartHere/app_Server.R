## =============================================================================

# app_Server.R 

# DESCRIPTION: 


#                           TABLE OF CONTENTS: 


## =============================================================================

appServer <- function(input,output,session){
  
  ## ===========================================================================
  ## 1) GENERAL SERVER FUNCTIONS
  ## ===========================================================================
  
  # To close the application and shutoff database connection
  source('source/b_Server/stopApp.R', local=TRUE)
  
  # File upload and import settings
  source('source/b_Server/fileUploadColAssignment.R', local=TRUE)
  
  
  
  
  
  

  
  # 
  # hide("nextButton")
  # hide("previousButton")
  # hide("manualPlotSelect")
  # hide("manualPlotSelectEnd")
  # hide("getPCA")
  # hide("updateUNTSelections")
  # 
  # 
  # ## ===========================================================================
  # ## 1) GENERAL SERVER FUNCTIONS
  # ## ===========================================================================
  # 
  # # Init reactive values
  # source('source/ServerFunctions/init_rv.R', local=TRUE)
  # 
  # # Code for interacting with files table
  # source('source/ServerFunctions/mainPanel_filesTable.R', local=TRUE)
  # 
  # # Code for plotting from UNT (Unique Names Table)
  # source('source/ServerFunctions/PlotFromUNT.R', local=TRUE)
  # 
  # # Code for exporting from library 
  # source('source/ServerFunctions/exportTab.R', local=TRUE)
  # 
  # 
  # # Helper functions related to database
  # source('source/ServerFunctions/HelperFunctionsDB.R', local=TRUE)
  # 
  # 
  # ## ===========================================================================
  # ## 2) DATABASE BUILDER
  # ## ===========================================================================
  # # Functionality for "Build Database" button
  # source('source/ServerFunctions/Builder/BuildDB.R', local=TRUE)
  # 
  # ## ===========================================================================
  # ## 3) DATABASE VIEWER
  # ## ===========================================================================
  # # Functionality for "Load Database" button
  # source('source/ServerFunctions/Viewer/LoadDB.R', local=TRUE)
  # 
  # ## ===========================================================================
  # ## 4) DATABASE SEARCH
  # ## ===========================================================================
  # # Functionality for "Search Database" button
  # source('source/ServerFunctions/Search/startHere_searchTool_sidebar.R', 
  #        local=TRUE)
  # 
  # # Import the query spectra
  # source('source/ServerFunctions/Search/a_importfile_preloadData.R', 
  #        local=TRUE)
  # 
  # # Create unique names table (UNT) from library
  # source('source/ServerFunctions/Search/b_create_rvForUNT.R', 
  #        local=TRUE)
  # 
  # # Two pass search with cosine similarity (not in use currently)
  # source('source/ServerFunctions/Search/c_twoPassSearch_cosineSimilarity.R', 
  #        local=TRUE)
  # 
  # # Other relevant observeEvents during the search process
  # source('source/ServerFunctions/Search/other_observeEventsForSearch.R', 
  #        local=TRUE)
  # 
  # 
  # source("source/Serverfunctions/dMinSim_onTheSpot.R", local = TRUE)
  # 
  # source("source/Serverfunctions/updateEvaluatorPlots.R", local = TRUE)
  # 
  # ## ===========================================================================
  # ## 4) MISC. CODE
  # ## ===========================================================================
  # observeEvent(input$uniqueNameTable_rows_selected, {
  #   # Reset tab selected to prevent subscript out of bounds
  #   rv$tabSelected = 1
  #   # Get currently selected row for uniqueName table
  #   rv$uniqueNameRow = input$uniqueNameTable_rows_selected
  # })
  # 
  # 
  # observeEvent(input$tab, {
  #   req(isTruthy(input$uniqueNameTable_rows_selected))
  #   
  #   l = input$tab
  #   catalogmap = rv$catalogHashMap_tempSelection
  #   idx = which(catalogmap$cnum == input$tab)
  #   
  #   rv$tabSelected <- idx
  # })
  # 
  # 
  # output$plotUI <- renderUI({
  #   req(isTruthy(input$uniqueNameTable_rows_selected))
  #   uniqueNames = rv$uniqueNames
  #   r = rv$numFiles
  #   
  #   # Get all catalog codes for current selection
  #   catalogNames = uniqueNames$catalogName[[rv$uniqueNameRow]]
  #   # Create temporary data frame of a hashmap of tab number (id) to catalog #
  #   rv$catalogHashMap_tempSelection = data.frame(
  #     id = 1:length(catalogNames),
  #     cnum = catalogNames
  #   )
  #   
  #   do.call(tabsetPanel, c(id='tab',lapply(1:r, function(i) {
  #     tabPanel(title = paste0(catalogNames[[i]]))
  #   })))
  # })
  # 
  # 
  # 
  # output$combinedPlot <- renderPlotly({
  #   
  #   # Load all of the files with the current selection
  #   req(isTruthy(input$uniqueNameTable_rows_selected) && 
  #         # isTruthy(input$tab) &&
  #         isTruthy(rv$uniqueNames))
  #   uniqueNames = rv$uniqueNames
  #   idx = input$uniqueNameTable_rows_selected
  #   
  #   filesToLoad = uniqueNames$filename[[idx]]
  #   r = length(filesToLoad)
  #   
  #   
  #   allticks = c()
  #   
  #   for (i in 1:r){
  #     # Create empty data frame
  #     # Save the loaded file into a vector
  #     
  #     fileToLoad = uniqueNames$filename[[idx]][[i]]
  #     # Get catnumber
  #     fields = extract_from_name(fileToLoad)
  #     catnum = fields[4]
  #     allticks = c(allticks, catnum)
  #     # Load the spectra
  #     directory = paste0(rv$Select_Folder, "/", fileToLoad)
  #     spectra = asm_spec2dt(asm_specImport(directory))
  #     
  #     # Normalization here
  #     normalize_func <- function(x){
  #       100*(x/maxxi)
  #     }
  #     maxxi = max(spectra[, "ab"])
  #     spectra[, "ab"] = lapply(spectra[, "ab"], normalize_func)
  #     
  #     q <- ggplot(spectra, aes(x = mz, y = ab)) +
  #       labs(x="*m/z*",
  #            y="Relative Intensity (%)") +
  #       geom_line() + 
  #       # Peaks defined in list 2, rows 9 and 10
  #       # Valleys defined in list 3, rows 9 and 10
  #       stat_peaks(geom = "point", color = "red", ignore_threshold = 0.0) + 
  #       stat_valleys(geom = "point", color = "blue", ignore_threshold = 0.0)
  #     
  #     
  #     
  #     pq = ggplot_build(q)
  #     
  #     # Find peaks
  #     xint = as.numeric(unlist(pq$data[[2]][9]))
  #     yint = as.numeric(unlist(pq$data[[2]][10]))
  #     z = rep(as.character(catnum), each = length(xint))
  #     
  #     xintvalleys = as.numeric(unlist(pq$data[[3]][9]))
  #     yintvalleys = as.numeric(unlist(pq$data[[3]][10]))
  #     zvalleys = rep(as.character(catnum), each = length(xintvalleys))
  #     
  #     
  #     if (i == 1){
  #       combined_data = data.frame(x = xint,
  #                                  y = yint,
  #                                  z = z)
  #       
  #       combined_data = rbind(combined_data, data.frame(x = xintvalleys,
  #                                                       y = yintvalleys,
  #                                                       z = zvalleys))
  #       
  #     } else {
  #       combined_data = rbind(combined_data, data.frame(x = xint,
  #                                                       y = yint,
  #                                                       z = z))
  #       combined_data = rbind(combined_data, data.frame(x = xintvalleys,
  #                                                       y = yintvalleys,
  #                                                       z = zvalleys))
  #     }
  #   }
  #   
  #   fig <- plot_ly(combined_data, x = ~z, y = ~x, z = ~y,
  #                  type = 'scatter3d', mode = 'lines', color = ~z,
  #                  line = list(width = 6, reverscale = FALSE))
  #   fig <- fig %>% layout(autosize = F, width = 1000, height = 750, 
  #                         scene = list(xaxis = list(dtick = 1))
  #   )
  #   fig
  #   
  # })
  # 
  # 
  # output$LibraryPlot <- renderPlot({
  #   req(isTruthy(input$uniqueNameTable_rows_selected) && 
  #         isTruthy(input$tab) &&
  #         isTruthy(rv$uniqueNames))
  #   
  #   uniqueNames = rv$uniqueNames
  #   idx = input$uniqueNameTable_rows_selected
  #   nested_idx = as.numeric(rv$tabSelected)
  #   
  #   # Load first file in the list of uniqueNames
  #   ## ERROR - attempt to select more than one element in vectorIndex [[
  #   ## Catalog num WD171584 of DalbergiaNigra
  #   fileToLoad = uniqueNames$filename[[idx]][[nested_idx]]
  #   
  #   rv$numFiles = length(uniqueNames$filename[[idx]])
  #   rv$rowSelected = input$uniqueNameTable_rows_selected
  #   
  #   
  #   # ____________________________________________________, 
  #   
  #   
  #   directory = paste0(rv$Select_Folder, "/", fileToLoad)
  #   # data = readLines(directory)
  #   
  #   spectra = asm_spec2dt(asm_specImport(directory))
  #   
  #   # Normalization here
  #   normalize_func <- function(x){
  #     100*(x/maxxi)
  #   }
  #   maxxi = max(spectra[, "ab"])
  #   spectra[, "ab"] = lapply(spectra[, "ab"], normalize_func)
  #   
  #   # 
  #   # q <- ggplot(spectra, aes(x = mz, xend=mz, y=0, yend = ab)) +
  #   #   
  #   #   labs(
  #   #     # title=paste0(tit, " ", name),
  #   #        x="*m/z*",
  #   #        y="Relative Intensity (%)") +
  #   #   theme(axis.title.x = ggtext::element_markdown(size = 14), 
  #   #         axis.title.y = ggtext::element_markdown(size=14),
  #   #         plot.title = element_text(size=20),#, hjust=0.5),
  #   #         panel.grid.major = element_blank(),panel.grid.minor = element_blank(),
  #   #         panel.background = element_blank(),
  #   #         axis.line = element_line(color="black")) +
  #   #   geom_segment() + 
  #   #   stat_peaks(geom = "point", color =)
  #   
  #   
  #   q <- ggplot(spectra, aes(x = mz, y = ab)) +
  #     
  #     labs(
  #       # title=paste0(tit, " ", name),
  #       x="*m/z*",
  #       y="Relative Intensity  (%)") +
  #     theme(axis.title.x = ggtext::element_markdown(size = 14), 
  #           axis.title.y = ggtext::element_markdown(size=14),
  #           plot.title = element_text(size=20),#, hjust=0.5),
  #           panel.grid.major = element_blank(),panel.grid.minor = element_blank(),
  #           panel.background = element_blank(),
  #           axis.line = element_line(color="black")) +
  #     geom_line() + 
  #     stat_peaks(geom = "point", color = "red", ignore_threshold = 0.01) +
  #     stat_valleys(geom = "point", color = "blue", ignore_threshold = 0.0)
  #   
  #   
  #   
  #   pq = ggplot_build(q)
  #   
  #   xint = as.numeric(unlist(pq$data[[2]][9]))
  #   yint = as.numeric(unlist(pq$data[[2]][10]))
  #   q
  # })
  # 
  
  

  
}







