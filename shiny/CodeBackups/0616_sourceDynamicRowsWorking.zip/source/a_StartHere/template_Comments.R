## =============================================================================

# TITLE: 

# DESCRIPTION: 

#                             TABLE OF CONTENTS: 
#       1) LOAD FUNCTIONS
#       2) INIT VARIABLES
#             - 2A) initlaize library


## =============================================================================
## 1) LOAD FUNCTIONS
## =============================================================================


## -----------------------------------------------------------------------------
## 4a) Initialize library and characterstic vars 
## -----------------------------------------------------------------------------

# i) Create tabs for interactive targest _______________________________________

# Only proceed if trigger button pressed
if (!getTriggerButton()){return()}

#ECF0F1

# tags$style(type="text/css", "#file {height:40px; width:200px; 
#                       margin-top:-10px; 
#                       background-color: #ACB6C0 ; 
#                                    color: white; border-color: #DCE4EC
#                       }"),