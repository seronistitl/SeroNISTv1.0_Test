# ==============================================================================
# 
# TITLE: dataImport_addClasses.R
#
#                               DESCRIPTION
# This program renders a variable number of rows of UI inputs that allow the 
# user to individually add classes of data one at a time. Users may also combine
# classes as needed. 
# 
#                             TABLE OF CONTENTS
#       1) SELECT COLUMN WITH CLASS ASSIGNMENTS
#       2) ADD INDIVIDUAL CLASSES
#       2A)     Define UI for each class
#       2B)     Render UI 
#       2C)     Store reactive variables
#       3) CLEAR ALL CLASSES
#
# ==============================================================================

# ==============================================================================
# 1) SELECT COLUMN WITH CLASS ASSIGNMENTS
# ==============================================================================
# This observeEVent responds to user's column selection that contains class
# assignments, and computes how many unique classes are present in selected col.

observeEvent(input$selectClassCol, {
  rv$selectClassCol = input$selectClassCol
  
  # Compute unique classes in selected column
  newUniqueFromCol = unique(rv$df[, rv$selectClassCol])
  numAvailClass = dim(newUniqueFromCol)[1]
  # Store in reactive variable for use elsewhere
  rv$currUniqueClasses = newUniqueFromCol
  # Render multiple dropdown menu selectInput for unique classes
  output$uniqueClassesOutput <- renderUI({
    selectInput("uniqueClassesOutput", 
                # Update input text based on number of available classes
                paste0("Available classes (", numAvailClass, " Total): "), 
                choices = rv$currUniqueClasses,
                selected = rv$currUniqueClasses[1],
                multiple = TRUE
    ) # end selectInput
  }) # end renderUI
})


# ==============================================================================
# 2) ADD INDIVIDUAL CLASS
# ==============================================================================
# This observeEvent responds to the button to "add class" and dynamically 
# renders a row of UI inputs for class #, selected classes, number of rows per 
# class, textInput for overwriting class name, and a remove button for each
# added class. 

observeEvent(input$addClassBtn, {
  # ----------------------------------------------------------------------------
  # 1A) Define UI for each antigen
  # ----------------------------------------------------------------------------
  req(rv$addedClasses < 10 && isTruthy(input$uniqueClassesOutput))
  
  rv$addedClasses = rv$addedClasses + 1
  rv$classIndex = c(rv$classIndex, 
                    paste(input$uniqueClassesOutput, collapse = "; ")
  )
  
  output_list = list()
  
  # For the total number of classes added
  for (i in 1:rv$addedClasses){
    # Define dynamic number of input ID's    
    id = paste0("chosenClassesTxt_", i)
    idplus_1 = paste0("numRowsForClass_", i)
    idplus_2 = paste0("renameSelectedClass_", i)
    idplus_3 = paste0("xRemoveClass_", i)
    
    # Save each row of input definitions in output_list at index i
    output_list[[i]] = 
      div(fluidRow(
        # column for class number UI
        column(1, 
               div(
                 # number corresponds to i
                 i, 
                 style = ""
                 # style = "margin-top:0px; padding: 35px;"
               ) #end div
        ), # end column
        # column for selected classes
        column(4, 
               div(
                 textOutput(outputId = id),
                 style = ""
                 # style = "margin-top:25px; padding: 0px;"
               ) #end div
        ), # end column
        # column for number of rows for selected classes
        column(1, 
               div(
                 textOutput(outputId = idplus_1),
                 style = ""
                 # style = "margin-top: 20px; padding: 15px;"
               ) # end div
        ), #end column
        # column for textInput to rename class
        column(5, 
               div(
                 uiOutput(outputId = idplus_2),
                 style = "margin-top: -40px;"
               ) # end div
        ), # end column
        # column for remove buttons
        column(1,
               div(
                 uiOutput(outputId = idplus_3),
                 style = "margin-top: -45px; padding: 20px;"
               ) # end div
        ) #end column
      ), #end fluidRow
      br()
      ) # end div
  } # end i loop

  # ----------------------------------------------------------------------------
  # 1B) Render UI
  # ----------------------------------------------------------------------------
  # Render the dynamic number of rows of UI inputs defined above
  # with additional styling depending on number of added classes
  output$rowsOfClasses <- renderUI({
    if (rv$addedClasses > 3){
      div(output_list, 
          style = "padding: 45px; height:250px; overflow-y: scroll; 
          overflow-x: hidden;"
      ) # end div
    } else if (rv$addedClasses > 2) {
      div(output_list, 
          style = "padding: 45px; height:300px;"
      ) # end div
    } else if (rv$addedClasses > 1){
      div(output_list, 
          style = "padding: 45px; height:200px;"
      ) # end div
    } else {
      div(output_list, 
          style = "padding: 45px; height:100px;"
      ) # end div
    } # end conditional block
  }) # end renderUI
  
  # For each class, render the actual user inputs in each individual row
  for (i in 1:rv$addedClasses){
    local({
      i <- i
      # Define ID's again
      id = paste0("chosenClassesTxt_", i)
      idplus_1 = paste0("numRowsForClass_", i)
      idplus_2 = paste0("renameSelectedClass_", i)
      idplus_3 = paste0("xRemoveClass_", i)
      
      # Show work
      # print(paste0("ChosenText ID at [", i, "]:", id))
      # print(paste0("rv$addedClass at [", i, "]:", rv$classIndex[i]))
      # print(paste0("rv$addedClass at [[", i, "]]:", rv$classIndex[[i]]))
      
      # Render the outputs
      # render class number 
      output[[id]] = renderText({
        rv$classIndex[[i]]
      })
      
      # render Number of rows
      output[[idplus_1]] = renderText({
        5
      })
      
      # render textInputs
      output[[idplus_2]] = renderUI({
        textInput(idplus_2, label = "", value = "")
      })
      
      # Remove buttons
      output[[idplus_3]] = renderUI({
        actionButton(idplus_3,
                     label = HTML("<span class='small'><i class=
                                       'glyphicon glyphicon-remove'
                                       ></i></span>"))
      })
    }) # End local
  } # end i local loop
  
})


# ==============================================================================
# 3) CLEAR ALL CLASSES
# ==============================================================================
# This observeEvent responds to the "clear all" button for class selection, but
# is also called when a new column is selected for class assignment.

observeEvent(input$clearClassBtn, {
  
  # Find all inputs related to added classes in rv
  
})


