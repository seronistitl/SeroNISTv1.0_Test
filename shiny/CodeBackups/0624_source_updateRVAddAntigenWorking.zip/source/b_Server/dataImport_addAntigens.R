# ==============================================================================
# 
# TITLE: dataImport_addAntigens.R
#
#                               DESCRIPTION
# This program renders a variable number of rows of UI inputs that allow the 
# user to individually add entire columns of data, one row per antigen.
# 
#                             TABLE OF CONTENTS
#       1) SELECT NUMBER OF ANTIGENS
#       1A)     Define UI for each antigen
#       1B)     Render UI 
#       1C)     Store reactive variables
#       2) DYNAMIC INPUT FOR INDIVIDUAL ANTIGENS
#       2A)     Select column for antigen
#       2B)     (optional) Input text for antigen
#       2C)     (optional) Remove current antigen
#
# ==============================================================================


# ==============================================================================
# 1) SELECT NUMBER OF ANTIGENS
# ==============================================================================
# This observeEvent responds to the number of antigens "n" chosen from the 
# dropdown menu input$numDimensions, and dynamically renders n number of rows
# each containing a selectInput, textInput, and actionButton for each antigen.

observeEvent(input$numDimensions, {
  # ----------------------------------------------------------------------------
  # 1A) Define UI for each antigen
  # ----------------------------------------------------------------------------
  # Get number of desired numeric columns
  rv$numDimensions = input$numDimensions
  # Only continue if more than 0 columns expected
  req(rv$numDimensions > 0)
  # block other outputs until finished
  rv$done = FALSE
  # Get saved file import
  df = rv$df
  # Get numeric columns
  nums <- unlist(lapply(df, is.numeric), use.names = FALSE)
  # Get names of numeric columns
  numData_colnames = colnames(df[, nums])
  # Initialize empty output list
  output_list = list()
  
  # For number of antigens expected
  for (i in 1 : rv$numDimensions){
    # Define input IDs
    id = paste0("selectNumericCol_", i)
    idplus_1 = paste0("colRenameInput_", i)
    idplus_2 = paste0("removeDim_", i)
    
    # If the first output ID, add extra margin-top:50px styling
    if (i == 1){
      output_list[[i]] = 
        div(
          fluidRow(
            column(1, 
                   div(i,
                       style = "margin-top:35px"
                       ) # end div
            ), # end column
            column(5, 
                   uiOutput(outputId = id)
            ), # end column
            column(5, 
                   uiOutput(outputId = idplus_1) 
            ), # end column
            column(1,
                   div(
                     uiOutput(outputId = idplus_2),
                     style = "margin-top: -30px; padding: 15px;"
                   ) # end div
            ) # end column
          ), # end fluidRow
          style = "margin-top:-50px"
        ) # End div
    } else {
      # If subsequent outputs, do without margin-top:-50px; 
      output_list[[i]] = 
        div(
          fluidRow(
            column(1, 
                   div(i,
                       style = "margin-top:35px"
                       ) # end div
            ), # end column
            column(5, 
                   uiOutput(outputId = id)
            ), # end column
            column(5, 
                   uiOutput(outputId = idplus_1) 
            ), # end column
            column(1,
                   div(
                     uiOutput(outputId = idplus_2),
                     style = "margin-top: -30px; padding: 15px;"
                   ) #end div 
            ) # end column
          ), # end fluidRow
        ) # End div
    } # end conditional block
  } # End i loop
  
  # ----------------------------------------------------------------------------
  # 1B) Render UI
  # ----------------------------------------------------------------------------
  # Render the dynamic number of rows of UI inputs defined above
  # with additional styling depending on number of added classes
  output$rowsOfData <- renderUI({
    if (rv$numDimensions > 3){
      div(output_list, 
          style = "padding: 45px; height:250px; 
          overflow-y: scroll; overflow-x: hidden;"
      )
    } else if (rv$numDimensions > 2) {
      div(output_list, 
          style = "padding: 45px; height:300px;"
      )
    } else if (rv$numDimensions > 1){
      div(output_list, 
          style = "padding: 45px; height:200px;"
      )
    } else if (rv$numDimensions == 1) {
      div(output_list, 
          style = "padding: 45px; height:100px;"
      )
    } else {
      NULL
    }
  })
  

  # For each antigen, render the row of inputs  
  for (i in 1:rv$numDimensions){
    local({
      i<- i
      id = paste0("selectNumericCol_", i)
      idplus_1 = paste0("colRenameInput_", i)
      idplus_2 = paste0("removeDim_", i)
      
      # Render the dropdown menu for each antigen column select
      output[[id]] = renderUI({
        selectInput(id,
                    "",
                    choices = numData_colnames,
                    selected = numData_colnames[1])
      })
      
      # render textInput to give the antigen a new name
      output[[idplus_1]] = renderUI({
        div(
          textInput(idplus_1, "",
                    value = ""),
          style = "margin-top:-5px"
        ) # end div
      })
      # render the remove button for each antigen
      output[[idplus_2]] = renderUI({
        div(
          actionButton(idplus_2,
                       label = HTML("<span class='small'><i class=
                                       'glyphicon glyphicon-remove'
                                       ></i></span>")),
          style = "margin-top:30px"
        ) # end div
      })
    }) # end local
  } # end i loop
  
  
  # ----------------------------------------------------------------------------
  # 1C) Store reactive variables
  # ----------------------------------------------------------------------------
  # Initialize empty dataframe to store reactive variables
  addAntigenDF = data.frame(
    antigenNum = numeric(),
    selectNumericCol = character(), colSelect = character(),
    colRenameInput = character(), colRenamed = character(),
    removeDim = character(), removed = character()
  )
  
  # For each antigen, save the ID to reactive variable
  for (i in 1:rv$numDimensions){
    id = paste0("selectNumericCol_", i)
    idplus_1 = paste0("colRenameInput_", i)
    idplus_2 = paste0("removeDim_", i)
    
    # Check work
    # print(paste0("output[[ ]] i = ", i, ": ", output[[id]]))
    # Save fields to dataframe
    addAntigenDF[nrow(addAntigenDF)+1, ] = c(
      i, 
      id, numData_colnames[1],
      idplus_1, "",
      idplus_2, 0)
  }
  
  # Save dataframe to reactive variable
  rv$addAntigen = addAntigenDF
  # process complete
  rv$done = TRUE
  
  print(paste0("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$"))
  print(paste0("rv$addAntigen: ", rv$addAntigen))
  print(paste0("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$"))
  
  
}) # end observeEvent(input$numDimensions, {...})




# ==============================================================================
# 2) DYNAMIC INPUT FOR INDIVIDUAL ANTIGENS
# ==============================================================================
# ------------------------------------------------------------------------------
# 2A) Select column for antigen
# ------------------------------------------------------------------------------
# Dynamic number of selectInputs are observed here. User selects from each
# dropdown menu the column they wish to stage for import. 
observeEvent({sapply(rv$addAntigen$selectNumericCol, function(x){
  req(isTruthy(rv$addAntigen) && rv$done)
  print(paste0("=============================================="))
  print(paste0("x input:", x))
  print(paste0("SELECTNUMERIC COL: ", input[[x]]))
  
  req(isTruthy(input[[x]]))
  currInputX = input[[x]]
  # Update reactive variable 
  # Find index for current input
  print(paste0("%IN%:", which(rv$addAntigen$selectNumericCol == x)))
  idx2update = which(rv$addAntigen$selectNumericCol == x)
  
  rv$addAntigen$colSelect[idx2update] = currInputX
  
  # Print current values
  print(paste0("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"))
  print(paste0("NEW selectNumericCol:", rv$addAntigen$selectNumericCol))
  print(paste0("NEW colselect:", rv$addAntigen$colSelect))
        
  
  print(paste0("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"))
  
  input[[x]]} 
)}, {
}, ignoreInit = TRUE)

# ------------------------------------------------------------------------------
# 2B) (optional) Input text for antigen
# ------------------------------------------------------------------------------
# Dynamic number of text inputs. If the user wishes to enter a specific name for
# the antigen it is done here. 
observeEvent({sapply(rv$addAntigen$colRenameInput, function(x){
  req(isTruthy(rv$addAntigen) && rv$done)
  # print(paste0("=============================================="))
  # print(paste0("x input:", x))
  # print(paste0("COL RENAME INPUT: ", input[[x]]))
  input[[x]]} 
)}, {
}, ignoreInit = TRUE)

# ------------------------------------------------------------------------------
# 2C) (optional) Remove current antigen
# ------------------------------------------------------------------------------
# Dynamic number of remove buttons. User presses a button to remove the antigen
# in the corresponding row. 
observeEvent({sapply(rv$addAntigen$removeDim, function(x){
  req(isTruthy(rv$addAntigen) && rv$done)
  # print(paste0("=============================================="))
  # print(paste0("x input:", x))
  # print(paste0("REMOVE DIM: ", input[[x]]))
  input[[x]]} 
)}, {
}, ignoreInit = TRUE)
