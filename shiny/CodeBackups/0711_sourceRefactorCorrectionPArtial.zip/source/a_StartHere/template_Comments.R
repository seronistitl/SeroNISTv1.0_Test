# ==============================================================================
#
# TITLE: 
#
#                               DESCRIPTION
# Start the description here. 
# 
#                             TABLE OF CONTENTS: 
#       1) LOAD FUNCTIONS
#       2) INIT VARIABLES
#             2A) initlaize library
# 
#
#                             SUBDIRECTORIES 
#
# SUBDIR1/ - contains stuff in subdirecotry 1
# SUBDIR2/ - contains stuff from the other one
# 
#                                  NOTES
#       - This is a note where you describe any noteworthy tips,
#         and also continues on the next line. 
# ==============================================================================

# ==============================================================================
# 1) LOAD FUNCTIONS
# ==============================================================================
# ------------------------------------------------------------------------------
# 4a) Initialize library and characterstic vars
# ------------------------------------------------------------------------------

# i) Create tabs for interactive targets _______________________________________

# Only proceed if trigger button pressed
if (!getTriggerButton()){return()}

#ECF0F1

# tags$style(type="text/css", "#file {height:40px; width:200px; 
#                       margin-top:-10px; 
#                       background-color: #ACB6C0 ; 
#                                    color: white; border-color: #DCE4EC
#                       }"),