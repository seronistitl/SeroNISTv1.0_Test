# ==============================================================================
# 
# TITLE: dataImport_addClasses.R
#
#                               DESCRIPTION
# This program renders a variable number of rows of UI inputs that allow the 
# user to individually add classes of data one at a time. Users may also combine
# classes as needed. 
# 
#                             TABLE OF CONTENTS
#       1) SELECT COLUMN WITH CLASS ASSIGNMENTS
#       2) ADD INDIVIDUAL CLASSES
#       2A)     Define UI for each class
#       2B)     Render UI 
#       2C)     Store reactive variables
#       3) CLEAR ALL CLASSES
#
# ==============================================================================
getClassInputIDs <- function(i, uid){
  id = paste0("chosenClassesTxt_", i, uid)
  idplus_1 = paste0("numRowsForClass_", i, uid)
  idplus_2 = paste0("renameSelectedClass_", i, uid)
  idplus_3 = paste0("xRemoveClass_", i)
  
  return(c(id, idplus_1, idplus_2, idplus_3))
}


renderClassesAdded <- function(){
  output_list = list()
  
  # For the total number of classes added
  for (i in 1:rv$addedClasses){
    # Define dynamic number of input ID's    
    allClassIDs = getClassInputIDs(i, rv$numClassCount)
    id = allClassIDs[1]
    idplus_1 = allClassIDs[2]
    idplus_2 = allClassIDs[3]
    idplus_3 = allClassIDs[4]
    
    # Save each row of input definitions in output_list at index i
    output_list[[i]] = 
      div(fluidRow(
        # column for class number UI
        column(1, 
               div(
                 # number corresponds to i
                 i, 
                 style = ""
                 # style = "margin-top:0px; padding: 35px;"
               ) #end div
        ), # end column
        # column for selected classes
        column(4, 
               div(
                 textOutput(outputId = id),
                 style = ""
                 # style = "margin-top:25px; padding: 0px;"
               ) #end div
        ), # end column
        # column for number of rows for selected classes
        column(1, 
               div(
                 textOutput(outputId = idplus_1),
                 style = ""
                 # style = "margin-top: 20px; padding: 15px;"
               ) # end div
        ), #end column
        # column for textInput to rename class
        column(5, 
               div(
                 uiOutput(outputId = idplus_2),
                 style = "margin-top: -40px;"
               ) # end div
        ), # end column
        # column for remove buttons
        column(1,
               div(
                 uiOutput(outputId = idplus_3),
                 style = "margin-top: -45px; padding: 20px;"
               ) # end div
        ) #end column
      ), #end fluidRow
      br()
      ) # end div
  } # end i loop
  
  # ----------------------------------------------------------------------------
  # 1B) Render UI
  # ----------------------------------------------------------------------------
  # Render the dynamic number of rows of UI inputs defined above
  # with additional styling depending on number of added classes
  output$rowsOfClasses <- renderUI({
    if (rv$addedClasses > 3){
      div(output_list, 
          style = "padding: 45px; height:250px; overflow-y: scroll; 
          overflow-x: hidden;"
      ) # end div
    } else if (rv$addedClasses > 2) {
      div(output_list, 
          style = "padding: 45px; height:300px;"
      ) # end div
    } else if (rv$addedClasses > 1){
      div(output_list, 
          style = "padding: 45px; height:200px;"
      ) # end div
    } else {
      div(output_list, 
          style = "padding: 45px; height:100px;"
      ) # end div
    } # end conditional block
  }) # end renderUI
  
  # For each class, render the actual user inputs in each individual row
  for (i in 1:rv$addedClasses){
    local({
      i <- i
      # Define dynamic number of input ID's    
      allClassIDs = getClassInputIDs(i, rv$numClassCount)
      id = allClassIDs[1]
      idplus_1 = allClassIDs[2]
      idplus_2 = allClassIDs[3]
      idplus_3 = allClassIDs[4]
      
      # Show work
      # print(paste0("ChosenText ID at [", i, "]:", id))
      # print(paste0("rv$addedClass at [", i, "]:", rv$classIndex[i]))
      # print(paste0("rv$addedClass at [[", i, "]]:", rv$classIndex[[i]]))
      
      # Render the outputs
      # render class number 
      output[[id]] = renderText({
        rv$classIndex[[i]]
      })
      
      # render Number of rows
      output[[idplus_1]] = renderText({
        5
      })
      
      # render textInputs
      output[[idplus_2]] = renderUI({
        textInput(idplus_2, label = "", value = "")
      })
      
      # Remove buttons
      output[[idplus_3]] = renderUI({
        actionButton(idplus_3,
                     label = HTML("<span class='small'><i class=
                                       'glyphicon glyphicon-remove'
                                       ></i></span>"))
      })
    }) # End local
  } # end i local loop
  
  
  # ----------------------------------------------------------------------------
  # 1C) Store reactive variables
  # ----------------------------------------------------------------------------
  
  # Initialize empty dataframe to store reactive variables
  addClassDF = data.frame(
    classID = character(), classNum = numeric(),
    classesTxtID = character(), selectedClasses = character(),
    colRenameInput = character(), colRenamed = character(),
    removeClass = character(), removed = character()
  )
  
  # For each antigen, save the ID to reactive variable
  for (i in 1:rv$addedClasses){
    # Define dynamic number of input ID's    
    allClassIDs = getClassInputIDs(i, rv$numClassCount)
    id = allClassIDs[1]
    idplus_1 = allClassIDs[2]
    idplus_2 = allClassIDs[3]
    idplus_3 = allClassIDs[4]
    
    addClassDF[nrow(addClassDF)+1, ] = c(
      id, i,
      idplus_1, "",
      idplus_2, "",
      idplus_3, 0)
  }
  
  # Save dataframe to reactive variable
  rv$addClass = addClassDF
  
}


# ==============================================================================
# 1) SELECT COLUMN WITH CLASS ASSIGNMENTS
# ==============================================================================
# This observeEVent responds to user's column selection that contains class
# assignments, and computes how many unique classes are present in selected col.

observeEvent(input$selectClassCol, {
  rv$selectClassCol = input$selectClassCol
  
  # Compute unique classes in selected column
  newUniqueFromCol = unique(rv$df[, rv$selectClassCol])
  numAvailClass = dim(newUniqueFromCol)[1]
  # Store in reactive variable for use elsewhere
  rv$currUniqueClasses = newUniqueFromCol
  # Render multiple dropdown menu selectInput for unique classes
  output$uniqueClassesOutput <- renderUI({
    selectInput("uniqueClassesOutput", 
                # Update input text based on number of available classes
                paste0("Available classes (", numAvailClass, " Total): "), 
                choices = rv$currUniqueClasses,
                selected = rv$currUniqueClasses[1],
                multiple = TRUE
    ) # end selectInput
  }) # end renderUI
})


# ==============================================================================
# 2) ADD INDIVIDUAL CLASS
# ==============================================================================
# This observeEvent responds to the button to "add class" and dynamically 
# renders a row of UI inputs for class #, selected classes, number of rows per 
# class, textInput for overwriting class name, and a remove button for each
# added class. 

observeEvent(input$addClassBtn, {
  rv$doneClass = FALSE
  # ----------------------------------------------------------------------------
  # 1A) Define UI for each antigen
  # ----------------------------------------------------------------------------
  req(rv$addedClasses < 10 && isTruthy(input$uniqueClassesOutput))
  
  rv$addedClasses = rv$addedClasses + 1
  rv$numClassCount = rv$numClassCount + 1
  rv$classIndex = c(rv$classIndex, 
                    paste(input$uniqueClassesOutput, collapse = "; "))
  
  renderClassesAdded()

  rv$doneClass = TRUE
  
})


# ==============================================================================
# 3) CLEAR ALL CLASSES
# ==============================================================================
# This observeEvent responds to the "clear all" button for class selection, but
# is also called when a new column is selected for class assignment.

observeEvent(input$clearClassBtn, {
  
  # Find all inputs related to added classes in rv
  
})













# ------------------------------------------------------------------------------
# 2A) Select column for antigen
# ------------------------------------------------------------------------------
# # Dynamic number of selectInputs are observed here. User selects from each
# # dropdown menu the column they wish to stage for import. 
# observeEvent({sapply(rv$addClass$classTxtID, function(x){
#   req(isTruthy(rv$addClass) && rv$doneClass)
#   # print(paste0("=============================================="))
#   # print(paste0("x input:", x))
#   # print(paste0("SELECTNUMERIC COL: ", input[[x]]))
#   
#   # Only update the value if a value is provided (ie. not at startup)
#   currInputX = input[[x]]
#   # Update reactive variable 
#   # Find index for current input
#   # print(paste0("%IN%:", which(rv$addClass$selectNumericCol == x)))
#   req(isTruthy(input[[x]]))
#   idx2update = which(rv$addClass$classTxtID == x)
#   rv$addClass$selectedClasses[idx2update] = currInputX
#   
#   # Print current values
#   # print(paste0("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"))
#   # print(paste0("NEW selectNumericCol:", rv$addClass$selectNumericCol))
#   # print(paste0("NEW colselect:", rv$addClass$colSelect))
#   # print(paste0("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"))
#   
#   input[[x]]} 
# )}, {
# }, ignoreInit = TRUE)

# ------------------------------------------------------------------------------
# 2B) (optional) Input text for antigen
# ------------------------------------------------------------------------------
# Dynamic number of text inputs. If the user wishes to enter a specific name for
# the antigen it is done here. 
observeEvent({sapply(rv$addClass$colRenameInput, function(x){
  req(isTruthy(rv$addClass) && rv$doneClass)
  # print(paste0("=============================================="))
  # print(paste0("x input:", x))
  # print(paste0("COL RENAME INPUT: ", input[[x]]))
  currInputX = input[[x]]
  
  if (!isTruthy(input[[x]])){
    currInputX = ""
  }
  
  idx2update = which(rv$addClass$colRenameInput == x)
  rv$addClass$colRenamed[idx2update] = currInputX
  
  input[[x]]} 
  
  
)}, {
}, ignoreInit = TRUE)

# ------------------------------------------------------------------------------
# 2C) (optional) Remove current antigen
# ------------------------------------------------------------------------------
# Dynamic number of remove buttons. User presses a button to remove the antigen
# in the corresponding row. 
observeEvent({sapply(rv$addClass$removeClass, function(x){
  req(isTruthy(rv$addClass$removeClass) && rv$doneClass)
  # Check work
  # print(paste0("=============================================="))
  # print(paste0("x input:", x))
  # print(paste0("REMOVE DIM: ", input[[x]]))
  # Double check that value being updated is correct
  # print(paste0("rv$addClass$removed[]:", rv$addClass$removed[idx2update]))
  # print(paste0("input[[x]]:", currInputX))
  # print(paste0("=============================================="))
  
  # Get the value of the input
  currInputX = input[[x]]
  # If no input present, use default value
  if(!isTruthy(input[[x]])){
    currInputX = 0
  }
  
  # Find index of the current input x
  idx2update = which(rv$addClass$removeClass == x)
  # Update the saved current value of the obsEvent
  rv$addClass$removed[idx2update] = currInputX
  
  # Only do this if the button is actually pressed
  if (currInputX > 0){
    # Update the current number of antigens to be one less than the current
    currNumAnt = as.numeric(rv$addedClasses)
    newNumAnt = currNumAnt - 1
    # If 0, prevent out of bounds error
    if (newNumAnt < 0){ newNumAnt = 0}
    
    renderClassesAdded
  }
  
  # Return current input
  input[[x]]} 
)}, {
}, ignoreInit = TRUE)



