# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#                           Program Header Status  
#                             COMPLETED 01182024
#                   Header: 🗸  Comments:🗸   Refactored: 🗸          
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ==============================================================================
# 
# TITLE: sst_GUI_About.
#
#                               DESCRIPTION
# This program defines the UI for the About tab.
# 
#                             TABLE OF CONTENTS
#       1) MAIN LAYOUT
#
#
# ==============================================================================
# ==============================================================================
#
#                             1) MAIN LAYOUT
#
# ==============================================================================
# Export tab UI elements are defined here. 
# Overall tabPanel defined in source/a_StartHere/appUI.R. 
About_GUITAB <- tabPanel(
  "About",
  mainPanel(
    shinyjs::useShinyjs(),
    id = "aboutPanel", width = 12,

  ) # end mainPanel
) # end tabPanel
