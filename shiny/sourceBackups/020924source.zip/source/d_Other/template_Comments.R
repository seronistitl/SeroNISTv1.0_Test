# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#                           Program Header Status  
#                             COMPLETED ######
#                   Header: 🗸  Comments: 🗸   Refactored: 🗸         
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ==============================================================================
#
# TITLE: 
#
#                               DESCRIPTION
# Start the description here. 
# 
#                           TABLE OF CONTENTS: 
#       1) LOAD FUNCTIONS
#
#       2) INIT VARIABLES
#             2a) initlaize library
# 
#
#                             SUBDIRECTORIES 
#
# SUBDIR1/ - contains stuff in subdirecotry 1
# SUBDIR2/ - contains stuff from the other one
# 
#                                  NOTES
#       - This is a note where you describe any noteworthy tips,
#         and also continues on the next line. 
# ==============================================================================

# ==============================================================================
#
#                           1) LOAD FUNCTIONS
#
# ==============================================================================
# ------------------------------------------------------------------------------
# 4a) Initialize library and characterstic vars
# ------------------------------------------------------------------------------

# i) Create tabs for interactive targets _______________________________________





# ==============================================================================
#                              !!!WARNING!!!
#                             AS OF 06/20/2023
#                       DO NOT AUTO-INDENT THIS FILE
# ==============================================================================






# regular comment 
## 090123 - example date tag for later referencing
### - error/warning and needs to be double checked
#### - contains important dataframe column names for reference



## USEFUL CODE SNIPPETS ________________________________________________________

# Only proceed if trigger button pressed
if (!getTriggerButton()){return()}


# tags$style(type="text/css", "#file {height:40px; width:200px; 
#                       margin-top:-10px; 
#                       background-color: #ACB6C0 ; 
#                                    color: white; border-color: #DCE4EC
#                       }"),