# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#                           Program Header Status  
#                             COMPLETED 091823
#                   Header: 🗸  Comments: 🗸   Refactored: 🗸         
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ==============================================================================
#
# TITLE: b_Server/testData_submitImport.R 
#
#                               DESCRIPTION
# This program contains code that responds to the "Submit" button to import data
# and apply filters and selections made by the user and save to the SQL database
# backend. Some initial plots of the selected data are also rendered.
#
#                             TABLE OF CONTENTS
#       1) SUBMIT BUTTON BEHAVIOR
#
#       2) DATA IMPORT & APPLY SETTINGS
#             2a) Apply row and column filters
#             2b) Get positive and negative class
#             2c) Get additional metadata
#
#       3) UPDATE ACTION LOG
#
#                                 NOTES
#
# ==============================================================================
# ==============================================================================
# 
#                        1) SUBMIT BUTTON BEHAVIOR
#
# ==============================================================================
# This observeEvent responds to the submit button and requires the user to first
# assign a sufficient number of antigens and classes for their uploaded data.
observeEvent(input$testData_submitImport, {
  req(isTruthy(rv$testData_addAntigen) &&  isTruthy(rv$testData_addClass) && 
        dim(rv$testData_addAntigen)[1] > 1 && dim(rv$testData_addClass)[1] > 0)
  # # Lock reactive variables
  # lock_testData$done1 = FALSE
  # # lock_testData$done2 = FALSE
  # lock_testData$done3 = FALSE
  # 
  # [lock_import$done1]
  testData_applyDataImportSettings()
  
  # # Get antigen and positive/negative class data and optional metadata
  # # [lock_import$done2] --> rv$positives and rv$negatives 
  # getAntigenPosNegClasses() 
  
  # # Get optional metadata
  # assignOptionalCols()
  testData_renderRawDataTable()
  
  testData_renderFilteredDataTable()

  # testData_renderDependentDropdownMenus()
  
  
  # Display tabs for plots to be rendered now
  output$testData_initialImportPlotTabs <- renderUI({
    tabsetPanel(type = "tabs",
                tabPanel("Raw Data", 
                         # plotlyOutput("firstGraph", height = "900px", width = "900px")
                         plotlyOutput("testData_firstGraph", height = "700px")
                         
                ),
                tabPanel("Log Data",
                         # plotlyOutput("logGraph", height = "900px", width = "900px"),
                         plotlyOutput("testData_logGraph", height = "700px"),
                         
                         
                )
    ) # end tabsetPanel for plots ) # hidden
  })

  output$testData_firstGraph <- renderPlotly({
    # Plot raw data
    testData_plot_rawData("dataImport", "init")
  })
  
  
  # Populate initial plots on evaluate tab
  output$testData_logGraph <- renderPlotly({
    testData_plot_logTransformData("dataImport", "init")
    
  })
  
  
  # release lock to continue
  lock_testData$done3 = TRUE
  
  
  # # update action log for this button press
  # dataImportSubmit_updateActionLog()
  
})



















testData_renderFilteredDataTable <- function(){
  req(lock_testData$done1)
  
  # i) Identify numeric vs int columns _________________________________________
  df = rv$testData_filteredDF
  ## 120523 added
  allAntigenCols = unlist(as.character(rv$testData_addAntigen$colSelect))
  
  allMin = min(df[, allAntigenCols])
  
  allLgTransformed = logTransformation_2dArray_allMin(df[, allAntigenCols], allMin)
  
  colnames(allLgTransformed) = paste0("Log Transform ", colnames(allLgTransformed))
  df = cbind(df, allLgTransformed)
  
  # # Get numeric columns
  df2 = sapply(df, is.double)
  
  # Use this function to determine if a column contains only integers
  is_whole <- function(x){
    # Be prepared to handle non-numeric data (will crash)
    if (is.numeric(x)){
      all(floor(x) == x)
    } else {FALSE}
  }
  # Find which columns are integers (will return either NA or TRUE)
  df3 = sapply(df, is_whole)
  # Get the index of columns that contain only integers
  wholeidx = which(is.na(df3))
  trueidx = which(isTruthy(df3))
  # Set those columns to false so they are not adjusted for sigfigs
  df2[wholeidx] = FALSE
  df2[trueidx] = FALSE
  
  # ii) Raw datatable output ___________________________________________________
  output$testData_filteredDataTable <- DT::renderDataTable({
    req(lock_testData$done1)
    # For numeric columns (in df2), set sigfigs depending but only for double
    df[, df2] = df[, df2]  %>%
      mutate(across(everything(),
                    .fns = function(x) {format(round(x, 4), nsmall = 4)}))
    
    df
    
    # Other alternatives for sigfigs
    # df[, df4] = df[, df4]  %>%
    #   mutate(across(where(
    #     function(x) is.double(x) & 
    #       sapply(!sum(x%%1)==0, isFALSE)),
    #     .fns = function(x) {format(round(x, 4), nsmall = 4)}))
    #
    # df  %>%
    #   mutate(across(where(function(x) is.double(x) & !sum(x%%1)==0),
    #                 .fns = function(x) {format(round(x, 4), nsmall = 4)}))
    # 
    # mutate(across(where(function(x) is.numeric(x) & !is.integer(x)), 
    # sprintf, fmt = '%.2f'))
    # 
    # df = df %>%
    #   mutate(across(everything(), as.character))
    
  }, 
  escape = TRUE,
  filter = "top", # search box
  selection = "multiple", 
  # extensions = c("FixedHeader", "FixedColumns"), # Causes extra long scroll
  extensions = c("FixedColumns"),
  server = FALSE, # disable this for numeric sort
  options = list(
    paging = FALSE,
    scrollX = TRUE,
    scrollY = "500px",
    autoWidth = TRUE,
    fixedHeader = T,
    fixedColumns = list(leftColumns = 1),
    columnDefs = list(
      list(width = '100px', targets = 2:ncol(df) - 1)
    )
    
  ) # end option list
  ) # end renderDataTable
  
  # Render the tabs separating different datatables 
  output$testDataTableTabs <- renderUI({
    div(style = "margin-top: -100px", 
        tabsetPanel(type = "tabs", id = "testData_dataTableTabs", 
                    tabPanel("Raw Data",
                             div(
                               DT::dataTableOutput("testData_rawDataTable"),
                               style = "font-size:70%; margin-top: -100px"
                             )
                             
                    ), # end tabPanel
                    tabPanel("Selected Data", 
                             div(
                               DT::dataTableOutput("testData_filteredDataTable"),
                               style = "font-size:70%; margin-top: -100px"
                             )
                    )
        )
    )
  })
  
  
  
}



















observeEvent(input$testData_evalTabSubmitBtn, {
  req(lock_analysis$done4)
  
  # Display tabs for plots to be rendered now
  output$testData_initialImportPlotTabs <- renderUI({
    tabsetPanel(type = "tabs",
                tabPanel("Raw Data", 
                         # plotlyOutput("firstGraph", height = "900px", width = "900px")
                         plotlyOutput("testData_firstGraph", height = "700px")
                         
                ),
                tabPanel("Log Data",
                         # plotlyOutput("logGraph", height = "900px", width = "900px"),
                         plotlyOutput("testData_logGraph", height = "700px"),
                         
                         
                ),
                tabPanel(
                  rui$trainingTabNames[1],
                  plotlyOutput("testData_plotDataWithBoundary",
                               height = "700px")
                ),
                tabPanel(
                  rui$trainingTabNames[2], 
                  plotlyOutput("testData_plotDataWithOptimBoundary",
                               height = "700px")
                )
    ) # end tabsetPanel for plots ) # hidden
  })
  
  
  
  if (input$rawOrLogData == rui$rawOrLog[2]){
    positives = rv$lgPositives
    negatives = rv$lgNegatives
  } else {
    # Extract latest data
    positives = rv$positives
    negatives = rv$negatives
    
  }
  
  # Use a unique ID to track which search / session we are currently on
  uID = 1
  # Use initial guess as starting point
  A = op$outmat
  sigvals = op$sigvals
  thisAlen = length(A)
  
  # Initialize dataframe to store optimization outputs for each sigval
  allIterVals = data.frame(
    uID = numeric(),
    idx = numeric(),
    L = numeric(),
    sigma = numeric(),
    A = numeric()
  )
  
  withProgress({
    for (i in 1:length(sigvals)){
      
      currSig = sigvals[i]
      
      # optim_out = optim(par = A, fn = errorEstimate_forOptim, poss = positives,
      #                   negs = negatives, sigval = currSig, q = 0.5,
      #                   method = "L-BFGS-B",
      #                   # method = "BFGS"
      #                   control = list(ndeps = rep(1e-8, rv$numLen),
      #                                  reltol = 1e-16,
      #                                  maxit = 10000,
      #                                  abstol = 1e-16,  
      #                                  factr = 1e9
      #                   )
      # )
      optim_out = optim(par = A, fn = errorEstimate_forOptim, poss = positives,
                        negs = negatives, sigval = currSig, q = 0.5,
                        # method = "L-BFGS-B",
                        method = "BFGS",
                        
                        control = list(ndeps = rep(1e-8, rv$numLen),
                                       # control = list(ndeps = rep(1.49e-8, rv$numLen),
                                       reltol = 1e-20,
                                       maxit = 10000,
                                       abstol = 1e-20,
                                       pgtol = 1e-16,
                                       factr = 1e1)
      )
      
      # Update the parameters for the next iteration in the for loop
      Aimin1 = A
      A = optim_out$par
      objVal = optim_out$value
      
      #### Append the results using a helper function
      allIterVals = appendA2DF(allIterVals, uID, i,
                               objVal, currSig, Aimin1, thisAlen)
      
    } # end loop
    
  }) # end withProgress
  
  # Save all optimized models to reactive variable
  tst$allIterVals = allIterVals
  
  # View final model result for test data
  currIdx = 7
  finalA = allIterVals[which(allIterVals$idx == currIdx), "A"]
  
  # Similar to dataImport_submitImport.R/getAntigenPosNegClasses() function___________________
  
  tst$data = NULL
  
  # Get test data antigen and class selections 
  allAntigenCols_tst = unlist(as.character(rv$testData_addAntigen$colSelect))
  # Get classes 
  classesToFilter = unlist(rv$testData_addClass$selectedClasses)
  classesToFilter_tst = splitStringByDelim(classesToFilter, "; ")
  
  # Get class assignments only
  classCol_tst = rv$testData_filteredDF[, rv$testData_selectClassCol]
  classColName_tst = rv$testData_selectClassCol
  
  if (isOptionA("test")){
    # If option A, filter by user-selected column containing classes, 
    # and append antigen columns to class assignment column
    currData = as.data.frame(
      rv$testData_filteredDF[
        rv$testData_filteredDF[[rv$testData_selectClassCol]] %in% 
          classesToFilter_tst, 
        c(allAntigenCols_tst, rv$testData_selectClassCol)])
  } else {
    # Option B, classes already filtered by row select 
    currData = as.data.frame(
      rv$testData_filteredDF[, c(allAntigenCols_tst, rv$testData_selectClassCol)])
  }
  
  # Get colnames of antigens and classes (fil_var)
  x_var <- paste0(colnames(currData)[1])
  y_var <- paste0(colnames(currData)[2])
  if (rv$testData_numDimensions == 3){
    z_var = paste0(colnames(currData)[3])
  } else {
    z_var = NULL
  }
  fil_var <- paste0(colnames(classCol_tst))
  
  # Omit missing data
  currData_omitNA = na.omit(currData)
  # Redundant, but do this to prevent reuse of variable names
  currData_noNeg = currData_omitNA
  
  
  if (isOptionA("test")){
    
    # Option A, extract positive and negative classes
    testData_filtered = currData_noNeg[
      currData_noNeg[[fil_var]] %in% classesToFilter_tst, 
      allAntigenCols_tst]
  } else {
    
    # Option B, classes were manually selected using row select
    # Get class assignments selected by user
    thisClassCol = currData[[rv$testData_selectClassCol]]
    
    # Get user selected class info for positive class
    currRVClass = rv$testData_addClass[1, ]
    # Get the "class" identity
    # in this case Option B saves class as comma delimited sequences 
    # ie) class 1 = "row:seq1, row:seq2"
    rowsToSubset = currRVClass$selectedClasses
    # Take the above string and create numeric sequence from it
    posNumList = interpretSeqList(rowsToSubset)
    # Get the minimum from this list
    minPosNum = min(posNumList)
    # Correct index starting at 1
    if (minPosNum != 1){
      posNumList = posNumList - minPosNum + 1
    }
    
    maxPosNum = max(posNumList)
    
    # # Repeat above steps for negative class or second row of rv$addClass
    # ncurrRVClass = rv$addClass[2, ]
    # # Get user selected class info from gui
    # negRowsToSubset = ncurrRVClass$selectedClasses
    # # Take above string and create numeric sequence
    # negNumList = interpretSeqList(negRowsToSubset)
    # 
    # # Correct indices to follow after the pos class
    # minNegNum = min(negNumList)
    # negNumList = negNumList - minNegNum + 1 + maxPosNum
    
    # Option B, get classes 
    testData_filtered = currData_noNeg[posNumList, allAntigenCols_tst]
    # negatives = currData_noNeg[negNumList, allAntigenCols]
  }
  
  tst$data = testData_filtered
  
  
  
  
  # Project test data using model made from q=0.5 on training data ___________________________
  
  ### 083123 - change this to be the minimum  across both negatives and positives
  allMin = min(tst$data[, allAntigenCols_tst])
  # print(paste0("ALLMIN COMPUTE INIT:", allMin))
  # If log transform selected, perform transform here
  if (input$rawOrLogData == rui$rawOrLog[2]){
    tmp_tstData = tst$data
    
    
    allMin = -0.0106
    ### Do log transformation over data
    tstData_lgTransform = logTransformation_2dArray_allMin(tmp_tstData, allMin)
    
    # Remove infinite values resulting from log transform
    tstData_lgTransform = tstData_lgTransform[
      !is.infinite(rowSums(tstData_lgTransform[, allAntigenCols_tst])), ]
    
    # Save to reactive value
    tst$lgData = tstData_lgTransform
    
    
    tstData = tst$lgData
  } else {
    tstData = tst$data
    
  }
  
  allClasses = data.frame(className = rv$testData_addClass$selectedClasses,
                          classRename = rv$testData_addClass$colRenamed)
  
  computedClasses = computeClass(finalA, tstData, x_var, y_var, z_var, allClasses)
  
  # Get pD and mD for positive and negative classes
  # Get column names for positive and negatives
  px_var = colnames(positives)[1]
  py_var = colnames(positives)[2]
  # Repeat for negatives
  nx_var = colnames(negatives)[1]
  ny_var = colnames(negatives)[2]
  
  if (rv$testData_numDimensions == 3){
    # If third dimension
    nz_var = colnames(negatives)[3]
    pz_var = colnames(positives)[3]
  } else {
    nz_var = NULL
    pz_var = NULL
  }
  # Get all class information for positive and negative
  train_allClasses = data.frame(className = rv$addClass$selectedClasses,
                                classRename = rv$addClass$colRenamed)
  
  
  posClasses = computeClass(finalA, positives, 
                            px_var, py_var, pz_var, train_allClasses)
  negClasses = computeClass(finalA, negatives, 
                            nx_var, ny_var, nz_var, train_allClasses)
  
  # Find Qd
  Qd = mapPredictedClass_toQD(computedClasses)
  Pd = mapPredictedClass_toQD(posClasses)
  Md = mapPredictedClass_toQD(negClasses)
  
  print(paste0("Qd/Pd/Md:", Qd, "/", Pd, "/", Md))
  q1 = (Qd - Md)/(Pd - Md)
  
  print(paste0("q1:", q1))
  
  # ____________________________________________________________________________
  # Use a unique ID to track which search / session we are currently on
  uID = 1
  # Use initial guess as starting point
  A = finalA
  sigvals = op$sigvals
  thisAlen = length(A)
  
  # Initialize dataframe to store optimization outputs for each sigval
  q1AllIterVals = data.frame(
    uID = numeric(),
    idx = numeric(),
    L = numeric(),
    sigma = numeric(),
    A = numeric()
  )
  
  withProgress({
    for (i in 1:length(sigvals)){
      
      currSig = sigvals[i]
      optim_out = optim(par = A, fn = errorEstimate_forOptim, poss = positives,
                        negs = negatives, sigval = currSig, q = q1,
                        # method = "L-BFGS-B",
                        method = "BFGS",
                        
                        control = list(ndeps = rep(1e-8, rv$numLen),
                                       # control = list(ndeps = rep(1.49e-8, rv$numLen),
                                       reltol = 1e-20,
                                       maxit = 10000,
                                       abstol = 1e-20,
                                       pgtol = 1e-16,
                                       factr = 1e1)
      )
      # optim_out = optim(par = A, fn = errorEstimate_forOptim, poss = positives,
      #                   negs = negatives, sigval = currSig, q = q1,
      #                   method = "L-BFGS-B",
      #                   # method = "BFGS"
      #                   control = list(ndeps = rep(1e-8, rv$numLen),
      #                                  reltol = 1e-16,
      #                                  maxit = 10000,
      #                                  abstol = 1e-16,  
      #                                  factr = 1e9
      #                   )
      #                   #control = list(ndeps = 1e-6)
      # )
      
      # Update the parameters for the next iteration in the for loop
      Aimin1 = A
      A = optim_out$par
      objVal = optim_out$value
      
      #### Append the results using a helper function
      q1AllIterVals = appendA2DF(q1AllIterVals, uID, i,
                                 objVal, currSig, Aimin1, thisAlen)
      
    } # end loop
    
  }) # end withProgress
  
  # Save all optimized models to reactive variable
  tst$q1AllIterVals = q1AllIterVals
  
  # View final model result for test data
  currIdx = 7
  q1A = q1AllIterVals[which(q1AllIterVals$idx == currIdx), "A"]
  print(paste0("A from q1:", q1A))
  
  
  
  # ____________________________________________________________________________
  # STEP 2)  Find final prevalence estimate q2
  
  q1ComputedClasses = computeClass(q1A, tstData, x_var, y_var, z_var, allClasses)
  
  # # Get pD and mD for positive and negative classes
  # # Get column names for positive and negatives
  # px_var = colnames(positives)[1]
  # py_var = colnames(positives)[2]
  # nx_var = colnames(negatives)[1]
  # ny_var = colnames(negatives)[2]
  
  # # Get all class information for positive and negative
  # train_allClasses = data.frame(className = rv$addClass$selectedClasses,
  #                               classRename = rv$addClass$colRenamed)
  
  
  ### THIS IS NOT WORKING WITH SUPPLEMENTAL DATASET AGAINST ITSELF Antigens AGM
  q1PosClasses = computeClass(q1A, positives, px_var, py_var, pz_var, train_allClasses)
  q1NegClasses = computeClass(q1A, negatives, nx_var, ny_var, nz_var, train_allClasses)
  
  # Find Qd
  q1_Qd = mapPredictedClass_toQD(q1ComputedClasses)
  q1_Pd = mapPredictedClass_toQD(q1PosClasses)
  q1_Md = mapPredictedClass_toQD(q1NegClasses)
  
  
  q2 = (q1_Qd - q1_Md)/(q1_Pd - q1_Md)
  
  print(paste0("q2:", q2))
  
  
  # ____________________________________________________________________________
  # STEP 3-4) Get A of q2 and use it to classify test data
  
  # Use a unique ID to track which search / session we are currently on
  uID = 1
  # Use initial guess as starting point
  A = q1A
  sigvals = op$sigvals
  thisAlen = length(A)
  
  # Initialize dataframe to store optimization outputs for each sigval
  q2AllIterVals = data.frame(
    uID = numeric(),
    idx = numeric(),
    L = numeric(),
    sigma = numeric(),
    A = numeric()
  )
  
  withProgress({
    for (i in 1:length(sigvals)){
      
      currSig = sigvals[i]
      
      optim_out = optim(par = A, fn = errorEstimate_forOptim, poss = positives,
                        negs = negatives, sigval = currSig, q = q2,
                        # method = "L-BFGS-B",
                        method = "BFGS",
                        
                        control = list(ndeps = rep(1e-8, rv$numLen),
                                       # control = list(ndeps = rep(1.49e-8, rv$numLen),
                                       reltol = 1e-20,
                                       maxit = 10000,
                                       abstol = 1e-20,
                                       pgtol = 1e-16,
                                       factr = 1e1)
      )
      
      print(paste0("================================================="))
      print(paste0("Test data"))
      print(paste0("OPTIM PAR:", optim_out$par))
      print(paste0("OPTIM VALUE:", optim_out$value))
      print(paste0("OPTIM COUNTS:", optim_out$counts))
      print(paste0("OPTIM CONVERGENCE:", optim_out$convergence))
      print(paste0("OPTIM MESSAGE:", optim_out$message))
      print(paste0("================================================="))
      
      # optim_out = optim(par = A, fn = errorEstimate_forOptim, poss = positives,
      #                   negs = negatives, sigval = currSig, q = q2,
      #                   method = "L-BFGS-B",
      #                   
      #                   # method = "BFGS"
      #                   control = list(ndeps = rep(1e-8, rv$numLen),
      #                                  reltol = 1e-16,
      #                                  maxit = 10000,
      #                                  abstol = 1e-16,  
      #                                  factr = 1e9
      #                   )
      #                   #control = list(ndeps = 1e-6)
      # )
      
      # Update the parameters for the next iteration in the for loop
      Aimin1 = A
      A = optim_out$par
      objVal = optim_out$value
      
      #### Append the results using a helper function
      q2AllIterVals = appendA2DF(q2AllIterVals, uID, i,
                                 objVal, currSig, Aimin1, thisAlen)
      
    } # end loop
    
    # }) # end withProgress
    # 
    # 
    # withProgress({
    
    # Save all optimized models to reactive variable
    tst$q2AllIterVals = q2AllIterVals
    
    # View final model result for test data
    currIdx = 7
    q2A = q2AllIterVals[which(q2AllIterVals$idx == currIdx), "A"]
    tst$currOutmat = matrix(q2A, ncol = rv$testData_numDimensions + 1)
    q2ComputedClasses = computeClass(q2A, tstData, x_var, y_var, z_var, allClasses)
    # ____________________________________________________________________________
    
    lock_testData$done4 = TRUE
  })
  
  
  ## 010224
  
  # Get table sum stats for q2
  lstOfGroups = unique(q2ComputedClasses$allPredClass)
  if (NA %in% lstOfGroups){
    idx2replace = which(is.na(lstOfGroups))
    lstOfGroups[idx2replace] = "NA"
  }
  # Replace NAs with "NA"'s 
  q2ComputedClasses[is.na(q2ComputedClasses$allPredClass), "allPredClass"] = "NA"
  
  numGroups = length(lstOfGroups)
  tNumBoth = nrow(q2ComputedClasses)
  allRes = data.frame(
    classNum = numeric(),
    className = character(),
    accuracy = numeric(),
    inaccuracy = numeric()
  )
  
  for (i in 1:numGroups){
    currClass = lstOfGroups[i]
    totalInCurrGroup = nrow(q2ComputedClasses[q2ComputedClasses$allPredClass %in% currClass, ])
    print(paste0("Total in group:", totalInCurrGroup))
    
    
    res1 = totalInCurrGroup/tNumBoth
    res2 = 1 - res1
    
    # Set sigfigs
    res1 = format(round(res1, 4), nsmall = 4)
    res2 = format(round(res2, 4), nsmall = 4)
    
    if (i == 1){
      allRes[nrow(allRes)+1,] = c(
        i, currClass, res1, res2
      ) 
    } else {
      allRes[nrow(allRes)+1,] = c(
        i, currClass, res2, res1
      )  
      
    }
    
    allRes= allRes
  }
  
  output$testData_optimizedEvalResultsSum <- renderTable({
    thisRes = allRes[, c("accuracy", "inaccuracy")]
    thisRes = setnames(thisRes, lstOfGroups)
    
    
    row.names(thisRes) = lstOfGroups
    # Save to reactive variable to export
    rv$evaluateResultsSumm = thisRes
    # Return what will be displayed
    thisRes
  }, rownames = TRUE)
  
  
  
  # Display boundaries resulting from evaluation over test data
  output$testDataTrainingTabs <- testData_renderEvaluatorTables()
  
  testData_a_updateMatrixViewer()
  testData_b_updateMatrixViewer()
  testData_c_updateMatrixViewer()
  
  
  
  
  
  output$testData_plotDataWithOptimBoundary <- renderPlotly({
    toPlotDF = q2ComputedClasses
    x_var = colnames(q2ComputedClasses)[1]
    y_var = colnames(q2ComputedClasses)[2]
    fil_var = "allPredClass"
    compute_var = "allClassified"
    q <- ggplot(data = toPlotDF,
                aes(x = .data[[x_var]],
                    y = .data[[y_var]],
                    color = .data[[fil_var]],
                    text = paste0(x_var, ": ", .data[[x_var]],
                                  "\n", y_var, ": ", .data[[y_var]],
                                  "\n", compute_var, ": ", .data[[compute_var]],
                                  "\n", fil_var, ": ", .data[[fil_var]])
                )) + #xlim(minX, maxX) + ylim(minY,maxY) +
      geom_point()
    q = ggplotly(q, tooltip = c("text")) %>% layout(
      legend = list(
        orientation = 'h', x = 0.3, y = -0.2, 
        title = list(text = 'Legend: '),
        itemdoubleclick = TRUE
      )
    )
    
    q
    
    
    # if (rv$testData_numDimensions == 2){
    #   # testData_create_2dPlot_ly("dataImport", )
    # }
    # if (currChoice == rui$rawOrLog[1]){
    #   # Plot raw data
    #   testData_plot_rawData("eval", mode)
    # } else {
    #   # Plot log transformed data
    #   testData_plot_logTransformData("eval", mode)
    # }
  })
  
  
  
  
  
  
  
  
})

  
  
testData_renderEvaluatorTables <- function(){
  
  renderUI({
    tabsetPanel(
      type = "tabs", id = "testData_evaluatorTabs",
      
      tabPanel("Classifier Metrics", 
               br(),
               p("Uniform Uncertainty Bounds"), 
               br(),
               tableOutput("testData_boundUncertaintyRhoMax"),
               br(),
               # p("Initial Results"),
               # tableOutput("testData_evaluateResultsSumm"),
               # br(),
               p("Confusion Matrix"),
               tableOutput("testData_optimizedEvalResultsSum"),
               br(),
               
      ), # end tabPanel
      tabPanel("Matrix associated with Homotopy Optimization", 
               
               # allIter
               fluidRow(
                 column(4, tableOutput("testData_plotly3dMatViewer_q1")),
                 column(4, tableOutput("testData_plotly3DMatrixM_q1")),
               ),
               br(),
               
               fluidRow(
                 column(4, tableOutput("testData_matrixAViewer_q1"))
                 
               ),
               fluidRow(
                 column(6, tableOutput("testData_matrixStats_q1"))
                 
               ),
               fluidRow(
                 column(4, actionButton("testData_q1_nextA", "Next Matrix")),
                 column(4, actionButton("testData_q1_resetA", "Start Over"))
               ),
               
               
               # q1
               fluidRow(
                 column(4, tableOutput("testData_plotly3dMatViewer_q2")),
                 column(4, tableOutput("testData_plotly3DMatrixM_q2")),
               ),
               br(),
               
               fluidRow(
                 column(4, tableOutput("testData_matrixAViewer_q2"))
                 
               ),
               fluidRow(
                 column(6, tableOutput("testData_matrixStats_q2"))
                 
               ),
               fluidRow(
                 column(4, actionButton("testData_q2_nextA", "Next Matrix")),
                 column(4, actionButton("testData_q2_resetA", "Start Over"))
               ),
               
               
               # q2
               fluidRow(
                 column(4, tableOutput("testData_plotly3dMatViewer_q3")),
                 column(4, tableOutput("testData_plotly3DMatrixM_q3")),
               ),
               br(),
               
               fluidRow(
                 column(4, tableOutput("testData_matrixAViewer_q3"))
                 
               ),
               fluidRow(
                 column(6, tableOutput("testData_matrixStats_q3"))
                 
               ),
               fluidRow(
                 column(4, actionButton("testData_q3_nextA", "Next Matrix")),
                 column(4, actionButton("testData_q3_resetA", "Start Over"))
               ),
               
      ) # end tabPanel
      
      
      
      
    )
    
    
  })
}

  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
# ==============================================================================
# 
#                       2) DATA IMPORT & APPLY SETTINGS
#
# ==============================================================================
# ------------------------------------------------------------------------------
# 2a) Apply row and column filters
# ------------------------------------------------------------------------------
# This is the first helper called in a series of functions that respond to the
# "Submit" button press. This function extracts the antigen columns selected by
# the user, converts any non-numeric antigen columns to numeric and NA removal,
# and applies row selections if Option B was selected
testData_applyDataImportSettings <- function(){
  # If non-numeric columns selected for antigens, resolve here 
  tdf = rv$testData_originalDF
  
  # tdf = rv$originalDF
  # names of the columns for the user's selected antigens
  allAntigenCols = unlist(as.character(rv$testData_addAntigen$colSelect))
  # datatype in the antigen columns selected
  allColClasses = sapply(tdf, class)
  # all column names
  allColNames = colnames(tdf)
  
  # Go through each column and assign as numeric if needed
  for (i in 1:ncol(tdf)){
    # Get info about column i
    currCol = tdf[, i] 
    currColName = allColNames[i]
    # currClass = sapply(currCol, class)
    currClass = allColClasses[i]
    
    # If the column is not numeric and is an antigen column
    if (currClass != "numeric" && currColName %in% allAntigenCols){
      # Convert this column to numeric and unsave Nans
      convertAntigen = as.numeric(tdf[[currColName]])
      # Overwrite column with numeric
      tdf[[currColName]] = convertAntigen
    }
  }
  
  
  # Save new rv$df only if NA's exist after processing above for loop
  udf = tdf[rowSums(is.na(tdf[, allAntigenCols]))==0, ]
  
  rv$testData_filteredDF = udf
  
  all_cdf = data.frame()
  ## 090723 apply row filter
  if (!isOptionA("test")){
    print(paste0("OPTION B NOT TESTED FOR TEST DATA"))
    ### this should be disabled
    # colForClasses = rv$selectClassCol
    # Get number of classes added by user
    tnumclass = dim(rv$testData_addClass)[1]
    # For each class assigned by user
    for (i in 1:tnumclass){
      # Get the UI metadata for the current class
      currRVClass = rv$testData_addClass[i, ]
      # NOTE - Class names for Option B are encoded as row numbers
      # Example label of a class ie. "1:5, 10:12" for rows 1-5 and 10-12. 
      rowsToSubset = currRVClass$selectedClasses
      # The new class name, if provided
      colRenamed = currRVClass$colRenamed
      # Class number
      currClassNum = currRVClass$classNum
      
      # Check if column name valid, if not create one
      if (!isTruthy(colRenamed)){
        colRenamed = paste0("Class ", currClassNum)
      }
      # Get row numbers from the class 
      numList = interpretSeqList(rowsToSubset)
      # Filter the rows 
      cdf = udf[numList, ]
      
      ## 092223 Need to overwrite the cdf class column for this section
      optionBLabels = rep(colRenamed, length(numList))
      cdf = cbind(
        udf[numList, ],
        optionBLabels
      )
      
      rv$testData_selectClassCol = "optionBLabels"
      # Aggregate the results
      all_cdf = rbind(all_cdf, cdf)
    }
    
    ## 090823 MAY NEED NA CHECK SINCE SKIPPED ABOVE
    ### MAY NEED TO CHECK FILTER BOX EFFECT ON TABLE INDEX
    ## 092223 removed since adding extra column for new class name
    # setNames(all_cdf, colnames(udf))
    rv$testData_filteredDF = all_cdf
  }
  
  # Lock reactive variables
  lock_testData$done1 = TRUE
}

# # ------------------------------------------------------------------------------
# # 2b) Get positive and negative class
# # ------------------------------------------------------------------------------
# # This helper function extracts the classes from the previously curated data. 
# getAntigenPosNegClasses <- function(){
#   req(lock_import$done1)
#   
#   # Reset currently stored data
#   rv$positives = NULL
#   rv$negatives = NULL
#   
#   # Get antigen data only
#   allAntigenCols = unlist(as.character(rv$addAntigen$colSelect))
#   # Get classes
#   classesToFilter = unlist(rv$addClass$selectedClasses)
#   # Get class assignments only
#   classCol = rv$filteredDF[, rv$selectClassCol]
#   
#   # Select data for antigens selected and classes selected
#   if (isOptionA("train")){
#     # If option A, filter by user-selected column containing classes, 
#     # and append antigen columns to class assignment column
#     currData = as.data.frame(
#       rv$filteredDF[rv$filteredDF[[rv$selectClassCol]] %in% classesToFilter,
#                     c(allAntigenCols, rv$selectClassCol)])
#   } else {
#     # Option B, classes already filtered by row select 
#     currData = as.data.frame(
#       rv$filteredDF[, c(allAntigenCols, rv$selectClassCol)])
#     
#   }
#   
#   # Get colnames of antigens and classes (fil_var)
#   x_var <- paste0(colnames(currData)[1])
#   y_var <- paste0(colnames(currData)[2])
#   fil_var <- paste0(colnames(classCol))
#   
#   # Omit missing data
#   currData_omitNA = na.omit(currData)
#   # Redundant, but do this to prevent reuse of variable names
#   currData_noNeg = currData_omitNA
#   
#   if (isOptionA("train")){
#     # Option A, extract positive and negative classes
#     positives = currData_noNeg[currData_noNeg[[fil_var]] == classesToFilter[1], 
#                                allAntigenCols]
#     negatives = currData_noNeg[currData_noNeg[[fil_var]] == classesToFilter[2],
#                                allAntigenCols]
#   } else {
#     
#     # Option B, classes were manually selected using row select
#     # Get class assignments selected by user
#     thisClassCol = currData[[rv$selectClassCol]]
#     
#     # Get user selected class info for positive class
#     currRVClass = rv$addClass[1, ]
#     # Get the "class" identity
#     # in this case Option B saves class as comma delimited sequences 
#     # ie) class 1 = "row:seq1, row:seq2"
#     rowsToSubset = currRVClass$selectedClasses
#     # Take the above string and create numeric sequence from it
#     posNumList = interpretSeqList(rowsToSubset)
#     # Get the minimum from this list
#     minPosNum = min(posNumList)
#     # Correct index starting at 1
#     if (minPosNum != 1){
#       posNumList = posNumList - minPosNum + 1
#     }
#     
#     maxPosNum = max(posNumList)
#     
#     # Repeat above steps for negative class or second row of rv$addClass
#     ncurrRVClass = rv$addClass[2, ]
#     # Get user selected class info from gui
#     negRowsToSubset = ncurrRVClass$selectedClasses
#     # Take above string and create numeric sequence
#     negNumList = interpretSeqList(negRowsToSubset)
#     
#     # Correct indices to follow after the pos class
#     minNegNum = min(negNumList)
#     negNumList = negNumList - minNegNum + 1 + maxPosNum
#     
#     # Option B, get classes 
#     positives = currData_noNeg[posNumList, allAntigenCols]
#     negatives = currData_noNeg[negNumList, allAntigenCols]
#   }
#   
#   # Put into reactive variable
#   rv$positives = positives
#   rv$negatives = negatives
#   # release lock
#   lock_import$done2 = TRUE
# }
# 
# # ------------------------------------------------------------------------------
# # 2c) Get additional metadata
# # ------------------------------------------------------------------------------
# # This helper function applies user selections from dropdown menus to assign a 
# # sample ID column and additional column(s) for other metadata
# assignOptionalCols <- function(){
#   # Only continue if this lock is freed
#   req(lock_import$done1)
#   
#   checkCol = input$selectSampleIDCol
#   if (checkCol == rui$noneSel){
#     # Set to default value if no optional column selected
#     rv$sampleIDCol = NULL
#   } else {
#     rv$sampleIDCol = as.character(input$selectSampleIDCol)
#   }
#   
#   # if (!isTruthy(input$selectMetadataCols)){
#   #   # Set to default if no columns selected
#   #   rv$metadataCols = NULL
#   # } else {
#   #   rv$metadataCols = input$selectMetadataCols
#   #   currMetadataCols = rv$metadataCols
#   # }
#   
#   # # Check work
#   # print(paste0("Current SampleID Col:", rv$sampleIDCol))
#   # print(paste0("Current Metadata Col(s):", rv$metadataCols))
#   # print(paste0("Current antigens:", rv$addAntigen$colSelect))
#   # print(paste0("Current classes:",  rv$addClass$selectedClasses))
#   
#   # # Get other columns to see if there's any overlap
#   # currAntCols = rv$addAntigen$colSelect
#   # currClassCols = rv$addClass$selectedClasses
#   
#   # # Exclude redundant columns 
#   # if (isTruthy(currMetadataCols)){
#   #   # Iterate through all metadata columns selected
#   #   for (i in 1:length(rv$metadataCols)){
#   #     
#   #   }
#   # }
# }
# 
# 
# # ==============================================================================
# # 
# #                           3) UPDATE ACTION LOG
# #
# # ==============================================================================
# dataImportSubmit_updateActionLog <- function(){
#   req(lock_import$done3)
#   # Update action log for antigens added
#   thisrvAddAnt = as.data.frame(rv$addAntigen)
#   expandedAnt = paste0("Adding antigens using columns selected by user<br/>",
#                        "Antigens Selected: ", as.character(rv$numDimensions),
#                        "<br/>")
#   nAnt = nrow(thisrvAddAnt)
#   for (a in 1:nAnt){
#     currAnt = thisrvAddAnt[a, ]
#     if (a == nAnt){
#       # don't add break
#       tsep = ""
#     } else {
#       tsep = "<br/>"
#     }
#     
#     if (isTruthy(currAnt$colRenamed)){
#       expandedAnt = paste0(expandedAnt, 
#                            paste0("   [", currAnt$antigenNum, "] ", 
#                                   currAnt$colSelect, " as ", 
#                                   currAnt$colRenamed, tsep))
#     } else {
#       expandedAnt = paste0(expandedAnt, 
#                            paste0("   [", currAnt$antigenNum, "] ", 
#                                   currAnt$colSelect, tsep))
#     }
#   }
#   
#   updateActionLog(paste0(expandedAnt))
#   
#   
#   thisrvaddClass = as.data.frame(rv$addClass)
#   if (isOptionA("train")){
#     expandedClass = paste0("Adding classes using Option A by column \"", 
#                            rv$selectClassCol, "\"<br/>")
#     
#   } else {
#     expandedClass = "Adding classes using Option B, by row selections<br/>"
#     
#   }
#   expandedClass = paste0(expandedClass, 
#                          "Classes Selected: ", as.character(rv$numDimensions),
#                          "<br/>")
#   nClass = nrow(thisrvaddClass)
#   for (a in 1:nClass){
#     currClass = thisrvaddClass[a, ]
#     if (a == nClass){
#       # don't add break
#       tsep = ""
#     } else {
#       tsep = "<br/>"
#     }
#     
#     if (isTruthy(currClass$colRenamed)){
#       expandedClass = paste0(expandedClass, paste0(
#         "   [", currClass$classNum, "] ", currClass$selectedClasses, 
#         " as ", currClass$colRenamed, " with ", currClass$numRows, " rows", tsep))
#     } else {
#       expandedClass = paste0(expandedClass, paste0(
#         "   [", currClass$classNum, "] ", currClass$selectedClasses, 
#         " with ", currClass$numRows, " rows", tsep))
#     }
#   }
#   
#   updateActionLog(paste0(expandedClass))
# }

