# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#                           Program Header Status  
#                               IN PROGRESS
#                   Header: 🗸X  Comments: 🗸-  Refactored: 🗸        
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ==============================================================================
# 
# TITLE: dataImport_supportingObserveEvents.R
#
#                               DESCRIPTION
# This program contains short observeEvents that support the User interface
# relating to data import. 
#
#                             TABLE OF CONTENTS
#       1) DROPDOWN MENU STYLING 
#
#       2) ACTION LOG
#
#       3) PRE-IMPORT
#
#       4) SAMPLE ID COLUMN
#
#       5) OPTION A/B: ADDING CLASS BY ROW SELECTION
#
# ==============================================================================
# ==============================================================================
# 
#                       1) DROPDOWN MENU STYLING 
#
# ==============================================================================
# This function is used to highlight columns that may not be a best first pic
# for selection because they are either non-numeric or may not have all unique
# rows. The condition for determining which item is highlighted is determined
# before calling this function. 
colorInvalidColumns <- function(inputID, allColumns, inColumns){
  # Loop through all columns and create an HTML statement for color
  colorNonUniqueHTML = ""
  concatStmt = ""
  
  # Iterate through all columns
  for (i in 1:length(allColumns)){
    # If the current column i is not in the list of unique columns
    if (!(allColumns[i] %in% inColumns)){
      # Create custom color statement
      currStmt = paste0(inputID, " .option[data-value='", allColumns[i], "']{
          background: #f3b6b6 !important;
          color: black !important;
        width: 200px;
        font-size: 9pt;
      } ")
    } else {
      currStmt = paste0(inputID, " .option[data-value='", allColumns[i], "']{
        width: 200px;
        font-size: 9pt;
      } ")
    }
    # Add to end
    concatStmt = paste0(concatStmt, currStmt)
  }
  return(concatStmt)
}

# ==============================================================================
# 
#                           2) ACTION LOG
#
# ==============================================================================
# The action log tracks all major shiny app events in response to the user's
# interaction with the app. This program updates this log using reactive variables.
updateActionLog <- function(newMsg){
  
  # The separator used between lines
  tsep = "<br/><br/>"
  
  # If this is the first action being saved 
  if (actionLog$updateCount == 0){
    # Get session start time
    actionLog$dispMessage = paste0("Session Started: ", actionLog$sessionStart)
    # Update action count
    actionLog$updateCount = actionLog$updateCount + 1
  }
  
  # Get the existing log
  currMsg = actionLog$dispMessage
  
  # Only update if a valid message received
  if (isTruthy(newMsg)){
    # Update display message
    actionLog$dispMessage = c(currMsg, tsep,
                              actionLog$updateCount, ") ", newMsg)
    # Update action count
    actionLog$updateCount = actionLog$updateCount + 1
  }
  # print(paste0("NEW ACTION:", actionLog$dispMessage))
}

# This observeEvent simply renders the action log to display past messages
# A blank "" is passed in to account for viewing action log when no changes
# have been made. 
observeEvent(input$seeActionLog, {
  updateActionLog("")
  
  output$actionLog <- renderUI({
    HTML(actionLog$dispMessage)
  })
})

# ==============================================================================
# 
#                              3) PRE-IMPORT 
#
# ==============================================================================
# Save the user's row selection where the header is said to be located
observeEvent(input$specifyHeaderRow, {
  # Map "No Header" to row 0 for no header row specified
  if (input$specifyHeaderRow == "No Header"){
    rv$headerRow = 0
  } else {
    # Otherwise save the row number for the header
    rv$headerRow = input$specifyHeaderRow
  }
})

# This observeEvent updates the column range for data import from excel files
observeEvent(input$colRangeSelect, {
  INTERVAL = rui$colRangeMaxLim
  value = rv$minMaxCol
  newvalue = input$colRangeSelect
  
  # Update the column range to only allow an interval smaller than INTERVAL
  if(value[1] != newvalue[1] && newvalue[2] - newvalue[1] != INTERVAL)
    # Update slider accordingly
    updateSliderInput(session, "colRangeSelect", 
                      value = c(newvalue[1], newvalue[1] + INTERVAL))
  
  if(value[2] != newvalue[2] && newvalue[2] - newvalue[1] != INTERVAL)
    updateSliderInput(session, "colRangeSelect", 
                      value = c(newvalue[2] - INTERVAL, newvalue[2]))
  
  # Update to the latest range
  ### NOTE - this may not reflect the range used when submit was pressed
  rv$minMaxCol = input$colRangeSelect
}, ignoreInit = TRUE)


# ==============================================================================
# 
#                           4) SAMPLE ID COLUMN
#
# ==============================================================================
observeEvent(input$selectSampleIDCol, {
  rv$selectSampleIDCol = input$selectSampleIDCol
})






# ==============================================================================
# 
#                 5) OPTION A/B: ADDING CLASS BY ROW SELECTION
#
# ==============================================================================
# This observeEvent shows/hides certain UI based on if option A/B are selected
observeEvent(input$optionab, {
  # If Option A
  if (input$optionab == rui$optionAB[1]){
    # Option A selected
    show("uniqueClassesOutput")
    show("classAddnHeader")
    show("rowsOfClasses")
    show("selectClassCol")
    
    # Hide the following UI
    hide("classAddnHeader_B")
    hide("classRowsSelected")
    
  } else {
    # Option B selected
    hide("selectClassCol")
    hide("uniqueClassesOutput")
    hide("classAddnHeader")
    
    # Show the following UI
    show("classRowsSelected")
    show("classAddnHeader_B")
  }
  
  ### Warn user to clear all classes instead
  clearAddedClasses()
  
}, ignoreInit = TRUE)

# These outputs render the header above the class addition section
output$classAddnHeader <- renderUI({
  HTML(rui$classAddnHeader)
})

# This second header for class addition section is when Option B is selected
output$classAddnHeader_B <- renderUI({
  HTML(rui$classAddnHeader_B)
})


# observeEvent for responding to row selections in raw data table
observeEvent(input$rawDataTable_rows_selected, {
  
  rawInput = input$rawDataTable_rows_selected
  rv$rawNumRows = length(input$rawDataTable_rows_selected)
  # Use helper function to get the print statement
  rowSelectPrint = getCurrentRowSelect_toPrint(rawInput) 
  
  # Define the output when rows are selected or deselected
  output$classRowsSelected = renderText({
    as.character(rowSelectPrint)
  })
  
},
ignoreNULL = FALSE
)

# Helper function to determine the current row selection if any
getCurrentRowSelect_toPrint <- function(rawInput){
  # If valid rows were selected from the datatable
  if (isTruthy(rawInput)){
    # Process the string into a concise input
    rowSelectToPrint = splitNonConsecutives(rawInput)
  } else {
    rowSelectToPrint = "No Rows Selected"
  }
  
  return(rowSelectToPrint)
}

# This helper takes a string of random numbers and comma separates them
splitNonConsecutives <- function(lst){
  lst = sort(lst)
  splitList = split(lst, cumsum(c(0, diff(lst) > 1)))
  numSubLsts = length(splitList)
  outputStmt = ""
  
  for (i in 1:numSubLsts){
    lstToConcat = splitList[i]
    
    if (i == 1){
      outputStmt = paste0(outputStmt, as.character(lstToConcat))
    } else {
      outputStmt = paste0(outputStmt, ", ", as.character(lstToConcat))
      
    }
  }
  
  
  return(outputStmt)
}

# This helper takes a string of comma separated sequences/numbers and converts
# them to a numeric list of numbers
interpretSeqList <- function(str){
  numList = c()
  
  nums = strsplit(as.character(str), ", ")
  len = length(nums)[[1]]
  
  if (len == 1){
    numList = getColSequence(nums)
  } else {
    for (i in 1:len){
      numList = c(numList, getColSequence(nums))
    }
  }
  
  return(numList)
}

# This helper function breaks down a sequence into a list of numbers
getColSequence <- function (str){
  numList = c()
  colons = strsplit(as.character(str), ":")
  numList = as.vector(sapply(colons, as.integer))
  
  ll = numList[1]
  ul = numList[2]
  
  tseq = seq(ll,ul)
  return(tseq)
}

# This helper function simply checks which Class addition option is current
isOptionA <- function(mode){
  
  if (mode == "train"){
    currInput = input$optionab
  } else if (mode == "test"){
    currInput = input$testData_optionab
    
  }
 
  if (currInput == rui$optionAB[1]){
    return(TRUE)
  } else {
    return(FALSE)
  }
}



observeEvent(input$doneImportBtn, {
  tabSwitchNext()
})

observeEvent(input$updateAntigenSelect, { 
  tabSwitchNext()
  
})

observeEvent(input$updateClassSelect, { 
  tabSwitchNext()
  
})



tabSwitchNext <- function(){
  currIdx = which(rui$tabNamesImport == input$dataImportTabs)
  
  nextIdx = currIdx + 1
  if (nextIdx > rui$numTabsImport){
    nextIdx = rui$numTabsImport
  }
  
  
  updateTabsetPanel(session = session, inputId = "dataImportTabs",
                    selected = rui$tabNamesImport[nextIdx])
}

# TEST DATA ______________________________________________________________
observeEvent(input$testData_doneImportBtn, {
  testData_tabSwitchNext()
})

observeEvent(input$testData_updateAntigenSelect, { 
  testData_tabSwitchNext()
})

observeEvent(input$testData_updateClassSelect, { 
  testData_tabSwitchNext()
})


testData_tabSwitchNext <- function(){
  currIdx = which(rui$testTabNamesImport == input$testDataImportTabs)
  
  nextIdx = currIdx + 1
  if (nextIdx > rui$testData_numTabsImport){
    nextIdx = rui$testData_numTabsImport
  }
  
  updateTabsetPanel(session = session, inputId = "testDataImportTabs",
                    selected = rui$testTabNamesImport[nextIdx])
}

observeEvent(input$testData_specifyHeaderRow, {
  # Map "No Header" to row 0 for no header row specified
  if (input$testData_specifyHeaderRow == "No Header"){
    rv$testData_headerRow = 0
  } else {
    # Otherwise save the row number for the header
    rv$testData_headerRow = input$testData_specifyHeaderRow
  }
})


# observeEvent for responding to row selections in raw data table
observeEvent(input$testData_rawDataTable_rows_selected, {

  rawInput = input$testData_rawDataTable_rows_selected
  rv$testData_rawNumRows = length(input$testData_rawDataTable_rows_selected)
  # Use helper function to get the print statement
  rowSelectPrint = getCurrentRowSelect_toPrint(rawInput)

  # Define the output when rows are selected or deselected
  output$classRowsSelected = renderText({
    as.character(rowSelectPrint)
  })

},
ignoreNULL = FALSE
)



# TEST CLASSES 
# This observeEvent shows/hides certain UI based on if option A/B are selected
observeEvent(input$testData_optionab, {
  # If Option A
  if (input$testData_optionab == rui$optionAB[1]){
    # Option A selected
    show("testData_uniqueClassesOutput")
    show("testData_classAddnHeader")
    show("testData_rowsOfClasses")
    show("testData_selectClassCol")
    
    # Hide the following UI
    hide("testData_classAddnHeader_B")
    hide("testData_classRowsSelected")
    
  } else {
    # Option B selected
    hide("testData_selectClassCol")
    hide("testData_uniqueClassesOutput")
    hide("testData_classAddnHeader")
    
    # Show the following UI
    show("testData_classRowsSelected")
    show("testData_classAddnHeader_B")
  }
  
  ### Warn user to clear all classes instead
  testData_clearAddedClasses()
  
}, ignoreInit = TRUE)

# These outputs render the header above the class addition section
output$testData_classAddnHeader <- renderUI({
  HTML(rui$classAddnHeader)
})

# This second header for class addition section is when Option B is selected
output$testData_classAddnHeader_B <- renderUI({
  HTML(rui$classAddnHeader_B)
})


# observeEvent for responding to row selections in raw data table
observeEvent(input$testData_rawDataTable_rows_selected, {
  
  rawInput = input$testData_rawDataTable_rows_selected
  rv$testData_rawNumRows = length(input$testData_rawDataTable_rows_selected)
  # Use helper function to get the print statement
  rowSelectPrint = getCurrentRowSelect_toPrint(rawInput) 
  
  # Define the output when rows are selected or deselected
  output$testData_classRowsSelected = renderText({
    as.character(rowSelectPrint)
  })
  
},
ignoreNULL = FALSE
)



splitStringByDelim <- function(str, delim){
  
  res = strsplit(str, delim)
  res = unlist(res)
  
  return(res)
}

