# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#                           Program Header Status  
#                   Header: 🗸  Comments: X   Refactored: NA         
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ==============================================================================
# 
# TITLE: DataImportTraining_GUI.R
#
#                               DESCRIPTION
# This program defines the UI for the Database builder portion of the WDIT.
# Users can use this tab to select data to incorporate into the SQL database.
# 
#                             TABLE OF CONTENTS
#       1) FILE UPLOAD
#
#       2) PRE-IMPORT SETTINGS
#                   i) Row for selecting excel sheet and loading
#                   ii) Row for specifying header select
#                   iv) Numeric data import row
#                   v) Row for displaying selected antigens
#                   vi) Class selection row
#                   vii) Row to stage individual classes for import
#                   viii) Row for displaying classes currently staged for import
#                   ix) Display the raw data that was uploaded in a table 
#       1B)     
#       1C)     
#
# ==============================================================================

# Start definition of tabPanel, called by shiny/source/a_StartHere/appUI.R
Import_GUITAB <- tabPanel(
  "Data Import & Training", br(),
  # Start sidebarPanel
  sidebarPanel(
    shinyjs::useShinyjs(),
    id = "startingPanel", width = 12,
    
    # ==========================================================================
    #                           1) FILE UPLOAD
    # ==========================================================================
    # File upload button
    fluidRow(
      column(6,
             fileInput("fileUploadInput", rui$upload),
      ),
    ), # end fluidRow
    br(), 
    fluidRow(
      column(6, 
             # Data acquisition tabs are rendered in this output including the tools 
             # contained with each tab. The contents of each tab are rendered by calling
             # the helper function renderDataAcquisitionTabs() at the bottom of this
             # program. 
             uiOutput("dataAcquisitionTabs"),
             br(),
      ), 
      column(6, 
             uiOutput("dataTableTabs"),
             # div(
             #   DT::dataTableOutput("rawDataTable"),
             #   style = "font-size:70%; margin-top: -100px"
             # )
      ),
    ), # end fluidRow
    br(),
    # Row to display the initial data table display for the upload
    fluidRow(
      
      column(6, 
             uiOutput("initialImportPlotTabs"),
             
      ), # end column
      column(6, 
             uiOutput("dataTrainingTabs"),
             
      ) # end column
    ), # end fluidRow
    
    br(),
  ), # end sidebarPanel
  br(),
) # end tabPanel "Data Import & Training" 





Export_GUITAB <- tabPanel(
  "Export",
  sidebarPanel(
    shinyjs::useShinyjs(),
    id = "exportPanel", width = 12,
    # tabsetPanel(
    #   id = "exportOptions", 
      # tabPanel(rui$exportTabs[1], br(),
               fluidRow(
                 
                 column(6,
                        strong("Select a folder for export"), br(), br(),
                        shinyDirButton("exportDirChoose", "Browse", 
                                       "Select a folder for export",
                                       allowDirCreate = TRUE
                        )
                 ),
                 column(6, 
                        textOutput("chosenExportDir")
                 )
               ), # end fluidRow
               br(),
               fluidRow(
                 column(6, 
                        selectInput("whatToExport", 
                                    label = "Select data to export",
                                    choices = rui$whatToExport,
                                    selected = rui$whatToExport[rui$wteLength],
                                    multiple = FALSE
                                    # multiple = TRUE
                        )
                 ), # end column
                 column(6, 
                        selectInput("expFileType", 
                                    label = "Select a file format",
                                    choices = rui$expFileTypeChoices,
                                    selected = rui$expFileTypeChoices[1],
                                    multiple = FALSE)
                 ) # end column
               ), # end fluidRow
               br(),
               
      # ) # end tabPanel
      
      # ), # end tabPanel
    #   tabPanel(rui$exportTabs[2], br(),
    #            fluidRow(
    #              
    #              column(6,
    #                     strong("Select a folder to save SQL database"), br(), br(),
    #                     shinyDirButton("sql_exportDirChoose", "Browse", 
    #                                    "Select a folder for SQL backup",
    #                                    allowDirCreate = TRUE
    #                     )
    #              ),
    #              column(6, 
    #                     textOutput("sql_chosenExportDir")
    #              )
    #            ), # end fluidRow
    #            fluidRow(
    #              column(6,
    #                     textInput("sqlNameEntry", rui$sqlPrompt),
    #                     bsTooltip(id = "sqlNameEntry", 
    #                               title = paste0(rui$sqlOptionalLabel), 
    #                               placement = "top", trigger = "hover"),
    #              ),
    #            ),
    #            br(),
    #            
    #   ), # end tabPanel
    #   tabPanel(rui$exportTabs[3], br(),
    #            fluidRow(
    #              
    #              column(6,
    #                     strong("Select a folder for figures"), br(), br(),
    #                     shinyDirButton("figs_exportDirChoose", "Browse", 
    #                                    "Select a folder for figures",
    #                                    allowDirCreate = TRUE
    #                     )
    #              ),
    #              column(6, 
    #                     textOutput("figs_chosenExportDir")
    #              )
    #            ), # end fluidRow
    #            
    #   )
    # ),
    br(),
    fluidRow(
      column(12, 
             align = "right",
             actionButton("finalSubmitExport", "Export", width = "240px"))
    )
    
    
    
    # SQL Related ______________________________________________________________
    
    
  )
)


renderImportAndTrainingTabs <- function(){
  renderUI({
    
    tabsetPanel(
      type = "tabs", id = "trainingTabs", 
      tabPanel("Raw Data", 
               plotlyOutput("firstGraph", height = "700px")
      ),
      tabPanel("Log Data",
               plotlyOutput("logGraph", height = "700px"),
      ),
      tabPanel(
        rui$trainingTabNames[1],
        plotlyOutput("plotDataWithBoundary",
                     height = "700px")
      ),
      tabPanel(
        rui$trainingTabNames[2], 
        plotlyOutput("plotDataWithOptimBoundary",
                     height = "700px")
      )
    )
  })
}

renderEvaluatorTables <- function(){
  
  renderUI({
    tabsetPanel(
      type = "tabs", id = "evaluatorTabs",
      
      tabPanel("Classifier Metrics", 
               br(),
               p("Uniform Uncertainty Bounds"), 
               br(),
               tableOutput("boundUncertaintyRhoMax"),
               # br(),
               # p("Initial Results"),
               # tableOutput("evaluateResultsSumm"),
               br(),
               p("Confusion Matrix"),
               tableOutput("optimizedEvalResultsSum"),
               br(),
               
               ), # end tabPanel
      tabPanel("Matrix associated with Homotopy Optimization", 
               fluidRow(
                 column(4, tableOutput("plotly3dMatViewer")),
                 column(4, tableOutput("plotly3DMatrixM")),
               ),
               br(),
               
               fluidRow(
                 column(4, tableOutput("matrixAViewer"))
                 
               ),
               fluidRow(
                 column(4, tableOutput("matrixStats"))
                 
               ),
               fluidRow(
                 column(4, actionButton("nextA", "Matrix Viewer")),
                 column(4, actionButton("resetA", "Start Over"))
               )
               ) # end tabPanel
      
     
      
      
    )
 
  
  })
}

renderDataAcquisitionTabs <- function(){
  renderUI({
    # ==========================================================================
    #                       2) PRE-IMPORT SETTINGS
    # ==========================================================================
    # This subsection contains tools to specify header, excel sheet, and the
    # "Load" button that must be pressed before continuing.
    tabsetPanel(
      type = "tabs", id = "dataImportTabs",
      tabPanel(
        rui$tabNamesImport[1], br(),
        div(
          style = "height:500px; overflow-y:auto; overflow-x: hidden",
          fluidRow(
            column(12, 
                   # Dropdown menu to select excel sheet, file must be uploaded 
                   uiOutput("selectSheet"),
                   bsTooltip(id = "selectSheet", 
                             title = rui$selectSheet, 
                             placement = "top", trigger = "hover"),
            ) # end column
          ), # end fluidRow
          fluidRow(
            column(6, 
                   # Specify the row where the header begins (0 for no header)
                   uiOutput("specifyHeaderRow"),
                   bsTooltip(id = "specifyHeaderRow", 
                             title = rui$specifyHeaderRow, 
                             placement = "top", trigger = "hover"),
            ), # end column
            column(6, 
                   # align = "right",
                   actionButton("updateDataSelect", "Load",
                                width = "240px"),
                   bsTooltip(id = "updateDataSelect", 
                             title = rui$updateDataSelect, 
                             placement = "left", trigger = "hover"),
            ) # end column
          ), # end fluidRow
          
          br(), 
          uiOutput("separatingLine"),
          uiOutput("optionalSettingsTitle"),
          br(),
          fluidRow(
            column(6,  
                   # dropdown menu for column select
                   uiOutput("selectSampleIDCol"),
                   bsTooltip(id = "selectSampleIDCol", 
                             title = paste0(rui$sampleIDOptionalLabel), 
                             placement = "top", trigger = "hover"),
            ),
            column(6, 
                   # Dropdown menu for additional metadata
                   uiOutput("selectMetadataCols"),
                   bsTooltip(id = "selectMetadataCols", 
                             title = paste0(rui$metadataOptionalLabel),
                             placement = "top", trigger = "hover"
                   )
            ), # end column
          ), # end fluidRow
          br(), br(),
          fluidRow(
            column(12, 
                   align = "right",
                   uiOutput("doneImportBtn")
            ) # end column
          ), # end fluidRow
        )
      ), # end tabPanel
      tabPanel(
        rui$tabNamesImport[2], 
        div(
          style = "height:500px; overflow-y:auto; overflow-x: hidden",
          br(),
          # iii) Numeric data import row________________________________________________
          fluidRow(
            column(6, 
                   # Dropdown menu to select number of antigens to add
                   selectInput("numDimensions", 
                               rui$selectedAntigens, 
                               choices = rui$numPossibleAntigens,
                               selected = 1),
                   bsTooltip(id = "numDimensions", 
                             title = paste0("Provide the number of antigens you wish to submit for training."), 
                             placement = "top", trigger = "hover"),
            ), # end column
            column(6,
                   # checkbox to filter columns
                   checkboxInput("showNumeric_inDataImport",
                                 rui$dispOnlyNum,
                                 value = FALSE),
                   bsTooltip(id = "showNumeric_inDataImport", 
                             title = paste0("Columns highlighted in Red contain some non-numeric data. Check this box to display the columns with only numeric data."), 
                             placement = "left", trigger = "hover"),
            ) # end column
          ), # end fluidRow
          br(),
          fluidRow(
            # Raw HTML for column headers, see global.R for rui contents
            HTML(rui$dimAddnHeader),
            # Display a row for each antigen added
            uiOutput("rowsOfData")
          ), # end fluidRow
          fluidRow(
            column(12, 
                   div(
                     actionButton("updateAntigenSelect", "Next",
                                  width = "240px"),
                     bsTooltip(id = "updateAntigenSelect", 
                               title = rui$updateAntigenSelect, 
                               placement = "left", trigger = "hover"),
                     align = "right"
                   )
            )
          ) # end fluidRow
        ) # end div
      ),
      tabPanel(
        rui$tabNamesImport[3], 
        div(
          style = "height:500px; overflow-y:auto; overflow-x: hidden",
          br(),
          # v) Select option A/B
          fluidRow(
            id = "pickClassOption",
            column(6, 
                   radioButtons("optionab", label = "Choose how to assign classes:",
                                choices = rui$optionAB,
                                selected = rui$optionAB[1]
                   ),
                   bsTooltip(id = "optionab", 
                             title = paste0("[Option A]: Select a column from your upload to assign classes.<br/>[Option B]: Manually select rows from the table below to assign classes."), 
                             placement = "top", trigger = "hover"),
            ), # end column
            column(6, 
                   # Dropdown menu to select a column to select classes from
                   uiOutput("selectClassCol"),
                   bsTooltip(id = "selectClassCol", 
                             title = paste0("Select the column from your file upload to get class assignments for your data."), 
                             placement = "top", trigger = "hover"),
            )# end column
            
            
          ), #end fluidRow
          
          
          # vi) Class selection row ____________________________________________________
          # fluidRow(
          #   id = "optionA",
          # 
          #   # column(3, 
          #   #        # checkbox to autopopulate using classes from selected column
          #   #        checkboxInput("useAllAvailClasses", 
          #   #                      "Auto populate using all classes",
          #   #                      value = FALSE)
          #   # ), # end column
          #   # column(3,
          #   # checkbox for multiple upload support
          #   # checkboxInput("useMultiFileClass",
          #   #               "One class per file (multi-upload)",
          #   #               value = FALSE
          #   # )
          #   # ) # end column
          # ), # end fluidRow
          
          # vii) Row to stage individual classes for import ____________________________
          fluidRow(
            id = "optionA_pt2",
            column(6, 
                   # dropdown menu w/multi-select to select classes for import
                   uiOutput("uniqueClassesOutput"),
                   bsTooltip(id = "uniqueClassesOutput", 
                             title = paste0(rui$classSelectBSLabel), 
                             placement = "top", trigger = "hover"),
                   # Option B - show number of rows instead
                   hidden(uiOutput("classRowsSelected")),
                   bsTooltip(id = "classRowsSelected", 
                             title = paste0(rui$classRowSelectedBSLabel), 
                             placement = "top", trigger = "hover"),
                   
            ), # end column
            column(3, 
                   div(
                     # Button to add the selected class(es)
                     actionButton("addClassBtn", "Add Class"),
                     style = "margin-top: 20px;"
                   ) #end div
            ), # end column
            column(3, 
                   div(
                     # clear current selections of classes button
                     actionButton("clearClassBtn", "Clear all"),
                     bsTooltip(id = "clearClassBtn", 
                               title = paste0("Clear the assigned classes"), 
                               placement = "top", trigger = "hover"),
                     style = "margin-top: 20px;"
                   ) # end div
            ) # end column
          ), # end 
          
          # viii) Row for displaying classes currently staged for import _______________
          fluidRow(
            id = "optionA_pt3",
            # Raw HTML for class headers
            uiOutput("classAddnHeader"),
            hidden(uiOutput("classAddnHeader_B")),
            # Display a row of inputs for each class staged for import
            uiOutput("rowsOfClasses"),
          ), # end fluidRow
          # fluidRow(
          #   column(12, 
          #          div(
          #            actionButton("updateClassSelect", "Next",
          #                         width = "240px"),
          #            bsTooltip(id = "updateClassSelect", 
          #                      title = rui$updateClassSelect, 
          #                      placement = "left", trigger = "hover"),
          #            align = "right"
          #          )
          #   )
          # ) # end fluidRow
          br(),
          fluidRow(
            column(12, 
                   div(
                     # Submit button
                     actionButton("submitImport", "Submit"),
                     bsTooltip(id = "submitImport", 
                               title = paste0(rui$submitImportBSLabel), 
                               placement = "left", trigger = "hover"),
                     align = "right"
                   ) # end div
            ) # end column
          ) # end fluidRow
        ) # end div
      ), # end tabPanel
      tabPanel(
        rui$tabNamesImport[4],
        div(
          style = "height:500px; overflow-y:auto; overflow-x: hidden",
          br(),
          
          
          fluidRow(
            column(6,
                   radioButtons("rawOrLogData", label = "Choose data transformation:",
                                choices = rui$rawOrLog,
                                selected = rui$rawOrLog[1]
                   )
            ) # end column
          ), # end fluidRow
          fluidRow(
            column(6, 
                   sliderInput("bu_hyperparameter", "Uniform uncertainty regularization parameter",
                               min = 1, max = 1000, step = 10, value = 100)
                   ) # end column
          ), # end fluidRow
          fluidRow(
            column(6,
                   actionButton("evalTabSubmitBtn", "Evaluate")
                   
            ), # end column
          ), # end fluidRow
          br(), br(), br(), br(), br(), br(), br(), br(),
          fluidRow(
            
            column(12,
                   div(
                     uiOutput("evalTabOptimBtn"),
                     align = "right"
                   )
            )
            
          ),
          
          
          
          
          
          
          
          
          # iii) Row for selecting a column for sample ID (all unique values)___________
          
          
          
          br(),
          
        )
      ) # end div
    ) # end tabsetPanel
    # )
  })
}

