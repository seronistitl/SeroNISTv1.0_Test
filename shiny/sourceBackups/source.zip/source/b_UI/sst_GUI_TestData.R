

Test_GUITAB <- tabPanel(
  "Test Data",
  sidebarPanel(
    shinyjs::useShinyjs(),
    id = "testDataPanel", width = 12,
    
    fluidRow(
      column(6,
             fileInput("testData_fileUploadInput", rui$upload),
      ),
    ), # end fluidRow
    br(), 
    fluidRow(
      column(6, 
             uiOutput("testDataAcquisitionTabs"),
             br(),
      ), # end column
      column(6, 
             uiOutput("testDataTableTabs")
      ) # end column
    ), # end fluidRow
    br(),
    # Final submit button row
    fluidRow(
      column(6,
             uiOutput("testData_initialImportPlotTabs"),
      ), # end column
      column(6, 
             uiOutput("testDataTrainingTabs")
      ) # end column
      # column(4, 
      #        actionButton("testDataAcq_submitBtn", "Submit",
      #                     style = "width:330px")
      # )
    ), # end fluidRow
    br(),
  ), # end sidebarPanel
  br(),
) # end tabPanel "Test Data"


# # Row to display the initial data table display for the upload
# fluidRow(
#   column(6, 
#          div(
#            DT::dataTableOutput("testData_rawDataTable"),
#            style = "font-size:80%"
#          )
#          
#   ),
#   column(6, 
#          tabsetPanel(type = "tabs",
#                      tabPanel("Raw Data", 
#                               # plotlyOutput("firstGraph", height = "900px", width = "900px")
#                               plotlyOutput("testDataRawGraph", height = "700px")
#                               
#                      ),
#                      tabPanel("Log Data",
#                               # plotlyOutput("logGraph", height = "900px", width = "900px"),
#                               plotlyOutput("testDataLogGraph", height = "700px"),
#                               
#                               
#                      )
#          ) # end tabsetPanel for plots ) # hidden
#   ) # end column
# ), # end fluidRow
# br(),
# ) # end sidebarPanel                   
# ) # end tabPanel





renderTestDataAcquisitionTabs <- function(){
  renderUI({
    tabsetPanel(
      type = "tabs", id = "testDataImportTabs",
      tabPanel(
        rui$testTabNamesImport[1], br(),
        div(
          style = "height:500px; overflow-y:auto; overflow-x: hidden",
          fluidRow(
            column(12, 
                   # Dropdown menu to select excel sheet, file must be uploaded 
                   uiOutput("testData_selectSheet"),
                   bsTooltip(id = "testData_selectSheet", 
                             title = rui$selectSheet, 
                             placement = "top", trigger = "hover"),
            ), # end column
          ), # end fluidRow
          fluidRow(
            column(6, 
                   # Specify the row where the header begins (0 for no header)
                   uiOutput("testData_specifyHeaderRow"),
                   bsTooltip(id = "testData_specifyHeaderRow", 
                             title = rui$specifyHeaderRow, 
                             placement = "top", trigger = "hover"),
            ), # end column
            column(6, 
                   actionButton("testData_updateDataSelect", "Load",
                                width = "240px"),
                   bsTooltip(id = "testData_updateDataSelect", 
                             title = rui$updateDataSelect, 
                             placement = "left", trigger = "hover"),
            ) # end column
          ), # end fluidRow
          
          
          
          
          br(), 
          uiOutput("testData_separatingLine"), 
          uiOutput("testData_optionalSettingsTitle"),
          br(),
          fluidRow(
            column(6,  
                   # dropdown menu for column select
                   uiOutput("testData_selectSampleIDCol"),
                   bsTooltip(id = "testData_selectSampleIDCol", 
                             title = paste0(rui$sampleIDOptionalLabel), 
                             placement = "top", trigger = "hover"),
            ),
            column(6, 
                   # Dropdown menu for additional metadata
                   uiOutput("testData_selectMetadataCols"),
                   bsTooltip(id = "testData_selectMetadataCols", 
                             title = paste0(rui$metadataOptionalLabel),
                             placement = "top", trigger = "hover"
                   )
            ), # end column
          ), # end fluidRow
          br(), br(),
          fluidRow(
            column(12, 
                   align = "right",
                   uiOutput("testData_doneImportBtn") 
            ) # end column
          ), # end fluidRow
          
          
          
          
          
          
          
          
          
          
          
          
        ) # end div
      ), # end tabPanel
      tabPanel(
        rui$testTabNamesImport[2],
        div(
          style = "height:500px; overflow-y:auto; overflow-x: hidden",
          br(),
          # iii) Numeric data import row________________________________________________
          fluidRow(
            column(6,
                   # Dropdown menu to select number of antigens to add
                   selectInput("testData_numDimensions", 
                               rui$selectedAntigens,
                               choices = rui$numPossibleAntigens,
                               selected = 1),
                   bsTooltip(id = "testData_numDimensions",
                             title = paste0("Provide the number of antigens you wish to submit for training."),
                             placement = "top", trigger = "hover"),
            ), # end column
            column(3,
                   # checkbox to filter columns
                   checkboxInput("testData_showNumeric_inDataImport",
                                 rui$dispOnlyNum,
                                 value = FALSE),
                   bsTooltip(id = "testData_showNumeric_inDataImport",
                             title = paste0("Columns highlighted in Red contain some non-numeric data. Check this box to display the columns with only numeric data."),
                             placement = "left", trigger = "hover"),
            ) # end column
          ), # end fluidRow
          br(),
          fluidRow(
            # Raw HTML for column headers, see global.R for rui contents
            HTML(rui$dimAddnHeader),
            # Display a row for each antigen added
            uiOutput("testData_rowsOfData")
          ), # end fluidRow
          fluidRow(
            column(12,
                   div(
                     actionButton("testData_updateAntigenSelect", "Next",
                                  width = "240px"),
                     bsTooltip(id = "testData_updateAntigenSelect",
                               title = rui$updateAntigenSelect,
                               placement = "left", trigger = "hover"),
                     align = "right"
                   )
            )
          ) # end fluidRow
        ) # end div
      ),
      tabPanel(
        rui$testTabNamesImport[3],
        div(
          style = "height:500px; overflow-y:auto; overflow-x: hidden",
          br(),
          # v) Select option A/B
          fluidRow(
            id = "testData_pickClassOption",
            column(6,
                   radioButtons("testData_optionab", label = "Choose how to define classes:",
                                choices = rui$optionAB,
                                selected = rui$optionAB[1]
                   ),
                   bsTooltip(id = "testData_optionab",
                             title = paste0("[Option A]: Select a column from your upload to assign classes.<br/>[Option B]: Manually select rows from the table below to assign classes."),
                             placement = "top", trigger = "hover"),
            ), # end column
            column(6, 
                   uiOutput("testData_selectClassCol"),
                   bsTooltip(id = "testData_selectClassCol",
                             title = paste0("Select the column from your file upload to get class assignments for your data."),
                             placement = "top", trigger = "hover"),
            ) # end column
            
          ), #end fluidRow
          
          
          # vi) Class selection row ____________________________________________________
          # fluidRow(
          #   id = "testData_optionA",
          #   column(6,
          #          # Dropdown menu to select a column to select classes from
          #          uiOutput("testData_selectClassCol"),
          #          bsTooltip(id = "testData_selectClassCol",
          #                    title = paste0("Select the column from your file upload to get class assignments for your data."),
          #                    placement = "top", trigger = "hover"),
          #   ), # end column
          #   # column(3,
          #   #        # checkbox to autopopulate using classes from selected column
          #   #        checkboxInput("useAllAvailClasses",
          #   #                      "Auto populate using all classes",
          #   #                      value = FALSE)
          #   # ), # end column
          #   column(3,
          #          # checkbox for multiple upload support
          #          # checkboxInput("useMultiFileClass",
          #          #               "One class per file (multi-upload)",
          #          #               value = FALSE
          #          # )
          #   ) # end column
          # ), # end fluidRow
          
          # vii) Row to stage individual classes for import ____________________________
          fluidRow(
            id = "testData_optionA_pt2",
            column(6,
                   # dropdown menu w/multi-select to select classes for import
                   uiOutput("testData_uniqueClassesOutput"),
                   bsTooltip(id = "testData_uniqueClassesOutput",
                             title = paste0("Select one or more unique classes and press the Add Class button."),
                             placement = "top", trigger = "hover"),
                   # Option B - show number of rows instead
                   hidden(uiOutput("testData_classRowsSelected")),
                   bsTooltip(id = "testData_classRowsSelected",
                             title = paste0("This will display the rows selected for the current class to be added."),
                             placement = "top", trigger = "hover"),
                   
            ), # end column
            column(3,
                   div(
                     # Button to add the selected class(es)
                     actionButton("testData_addClassBtn", "Add Class"),
                     style = "margin-top: 20px;"
                   ) #end div
            ), # end column
            column(3,
                   div(
                     # clear current selections of classes button
                     actionButton("testData_clearClassBtn", "Clear all"),
                     bsTooltip(id = "testData_clearClassBtn",
                               title = paste0("Clear the assigned classes"),
                               placement = "top", trigger = "hover"),
                     style = "margin-top: 20px;"
                   ) # end div
            ) # end column
          ), # end fluidRow
          
          # viii) Row for displaying classes currently staged for import _______________
          fluidRow(
            id = "testData_optionA_pt3",
            # Raw HTML for class headers
            uiOutput("testData_classAddnHeader"),
            hidden(uiOutput("testData_classAddnHeader_B")),
            # Display a row of inputs for each class staged for import
            uiOutput("testData_rowsOfClasses"),
          ), # end fluidRow
          br(),
          # fluidRow(
          #   column(4,
          #          div(
          #            actionButton("testData_updateClassSelect", "Next",
          #                         width = "240px"),
          #            bsTooltip(id = "testData_updateClassSelect",
          #                      title = rui$updateClassSelect,
          #                      placement = "left", trigger = "hover"),
          #            align = "center"
          #          )
          #   )
          # ) # end fluidRow
          br(),
          fluidRow(
            column(12,
                   div(
                     # Submit button
                     actionButton("testData_submitImport", "Submit"),
                     bsTooltip(id = "testData_submitImport",
                               title = paste0(rui$submitImportBSLabel),
                               placement = "top", trigger = "hover"),
                     align = "right"
                     
                   )# end div
            ) # end column 
          ) # end fluidRow
        ) # end div
      ), # end tabPanel
      tabPanel(
        rui$testTabNamesImport[4],
        div(
          style = "height:500px; overflow-y:auto; overflow-x: hidden",
          br(),
          
          
          fluidRow(
            column(6,
                   actionButton("testData_evalTabSubmitBtn", 
                                "Optimize Classifier for Test Data"
                                )
                   
            ), # end column
          ), # end fluidRow
          br(), br(), br(), br(), br(), br(), br(), br(),
          fluidRow(
            
            column(12,
                   div(
                     uiOutput("testData_evalTabOptimBtn"),
                     align = "right"
                   )
            )
            
          ),
          
          
        )
      ) # end tabPAnel
    ) # end tabsetPanel
    # )
  })
}
